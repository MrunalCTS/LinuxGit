import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QualityCompanionComponent } from './quality.companion.component';

describe('QualityCompanionComponent', () => {
  let component: QualityCompanionComponent;
  let fixture: ComponentFixture<QualityCompanionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QualityCompanionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QualityCompanionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
