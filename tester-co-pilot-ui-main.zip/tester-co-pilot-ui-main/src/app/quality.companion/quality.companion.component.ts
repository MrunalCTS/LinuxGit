import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatRippleModule } from '@angular/material/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { Router, RouterModule } from '@angular/router';
import { EditorModule } from 'primeng/editor';
import { DialogContentExampleDialogComponent } from '../dialog-content-example-dialog/dialog-content-example-dialog.component';
import { BotWebSocketService } from '../bot-websocket.service';
import {ChangeDetectionStrategy, signal} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
// import {MatExpansionModule} from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
@Component({
  selector: 'app-quality.companion',
  standalone: true,
  imports: [
    MatTableModule,
    RouterModule,
    CommonModule,
    FormsModule,
    MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatTabsModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatButtonToggleModule,
    MatExpansionModule,
    ReactiveFormsModule,
    MatListModule,
    EditorModule,
    DialogContentExampleDialogComponent
  ],
  templateUrl: './quality.companion.component.html',
  styleUrl: './quality.companion.component.css'
})
export class QualityCompanionComponent implements OnInit{
  document: any;
  currentActual: any;
  currentRef: any;
  coverage: any;
  res: any;
  similarTCRES: any;
  tcDetails: any;
  Positive_Scenerios: any;
  Negative_Scenerios: any;
  Edge_Scenerios: any;
  ExistingCoverageScenerios: any;
  ExistingCoveragePositive: any;
  ExistingCoverageNegative: any;
  ExistingCoverageEdge: any;
  NewCoveragePositive: any;
  NewCoverageNegative: any;
  NewCoverageEdge: any;
  isLoading: boolean=false;
  displayedColumns: string[] = ['Similar_TC_IDName', 'TC_Description', 'SimilarityScore', 'Differences'];
  readonly panelOpenState = signal(false);
  // dataSource: any;
  dataSource = new MatTableDataSource<any>();
  correctnessVal: any=[];
  completenessVal: any=[];
  completenessKey: any[]=[];
  correctnessKey: any[]=[];
  stepsToHighlight: any;
  actualTCStepsToHighlight: any;
  refTCStepsToHighlight: any;
  currentUniqueWords: any;
  constructor(private route: Router,private botService: BotWebSocketService) {

  }
  ngOnInit(): void {
    this.isLoading=true;
    this.botService.getDocument().subscribe((data) => {
      
      console.log('Document received: ', data);
      this.isLoading=false;
      this.document=data.latest_document;
      console.log(this.document);
    //  this.document = data['latest_document']; 
    //  data=data['latest_document'];
    
    this.coverage = this.document?.Correctness;
//     this.coverage['Completeness'] = Object.values(this.coverage['Completeness']);
// this.coverage['Correctness'] = Object.values(this.coverage['Correctness']);
// this.completenessKey=Object.keys(this.coverage['Completeness'][0]);
// this.completenessVal=Object.values(this.coverage['Completeness'][0]);
this.completenessKey = Object.keys(this.coverage?.Completeness[0]);
this.completenessVal = this.coverage?.Completeness[0];
console.log(this.completenessKey,this.completenessVal);
// this.coverage['Completeness'] = this.coverage['Completeness'].reduce((acc:any, curr:any) => {
//   const key = Object.keys(curr)[0];
//   acc[key] = curr[key];
//   this.completenessVal=acc[key];
//   console.log(acc,Object.values(acc));
//   return acc;
// }, {});

this.correctnessKey=Object.keys(this.coverage.Correctness[0]);
this.correctnessVal=this.coverage.Correctness[0];
// this.coverage['Correctness'] = this.coverage['Correctness'].reduce((acc:any, curr:any) => {
//   const key = Object.keys(curr)[0];
//   acc[key] = curr[key];
//   this.correctnessVal=acc[key];
//   console.log(acc,Object.values(acc));
//   return acc;
// }, {});


    // this.coverage['Completeness']=
    //  Object.entries(this.coverage['Completeness']).map(([key, value]) => ({ value }));
      // this.coverage = JSON.parse(this.document.Correctness);
      // this.coverage['Correctness']=
      // Object.entries(this.coverage['Correctness']).map(([key, value]) => ({  value }));
      let dt = this.document.Coverage
      .replace(/'([^']+)'/g, '"$1"');  
      
    try{
      dt= JSON.parse(this.document.Coverage);

    console.log(dt)
    }catch(e)
    {
     
     
      console.log(e);
    
    }
      this.res = dt;
      this.similarTCRES = this.document.Redundancy;
      this.dataSource.data = this.similarTCRES;
      this.tcDetails = this.document?.TestCaseDetails;
      console.log("tcDetails",this.tcDetails);
       this.stepsToHighlight=this.document?.StepsToHighlight;
                        
      this.ExistingCoveragePositive=this.res["Existing Coverage"]["Positive Scenarios"];
      this.ExistingCoverageNegative=this.res["Existing Coverage"]["Negative Scenarios"];
      this.ExistingCoverageEdge=this.res["Existing Coverage"]["Edge Scenarios"];
      this.NewCoveragePositive=this.res["Missing Coverage"]["Positive Scenarios"];
      this.NewCoverageNegative=this.res["Missing Coverage"]["Negative Scenarios"];
      this.NewCoverageEdge=this.res["Missing Coverage"]["Edge Scenarios"];
      this.similarTcModification();
      
})
  //  this.similarTcModification()
    this.initializeWebSocketConnection();
  }
  buttonToggles = {
    info: 'info',
    links: 'links',
    docs: 'docs',
    media: 'media',
  };
  isOpen = false;
  // coverage={
  //   "Correctness": { 
  //     "Lack of Purpose": "The given test objective is not clear. It does not specify what exactly needs to be verified.", 
  //     "Incorrect TestSteps": "The test steps are not aligned with the objective mentioned in the test case title and description.", 
  //     "Lack of clarity": "None of the test steps are ambiguous or unclear.", 
  //     "Inconsistency": "There is no inconsistency in the terminology used." 
  // }, 
  // "Completeness": { 
  //     "Missing components": "None of the mandatory test components are missing.", 
  //     "Missing Steps": "The test steps are in a logical sequence and none of them are missing.", 
  //     "Missing Validation": "There are no missing validation criteria.", 
  //     "Missing Test data": "There is no missing test data." 
  // } 
  // }
  // res={
  //   'Existing Test Scenarios': { "Positive": ['Loan Application Form Fields', 'Loan Application Form Submission', 'Loan Application Submission', 'Accessing Loan Application Status', 'Error Message for Incomplete Loan Application', 'Loan Application Notification'], "Negative": [], "Edge": [] },
  //   'New Test Scenarios to be created': { "Positive": ['Loan Application Form Validation', 'Loan Application Form Field Length', 'Loan Application Form Field Format'],
  //     "Negative": ['Loan Application Form Empty Submission', 'Loan Application Form Invalid Submission'], "Edge": ['Loan Application Form Maximum Loan Amount', 'Loan Application Form Minimum Loan Amount']
  //    } 
  // }

  // similarTCRES=[
  //   {
  //      "ExpectedResults":"[\"The loan application form should be easily accessible from the bank\\'s website.\", \\'The loan application form should be eas... and loan amount requested.\\', \\'The user should receive a confirmation message after submitting the loan application form.\\']",
  //      "SimilarityScore":0.9488170146942139,
  //      "TestCaseDescription":"This test case verifies that the loan application form can be easily accessed, filled out, and submitted by the user. It ensu...sary fields are present and function as expected, and that the user receives a confirmation message after submitting the form.",
  //      "TestCaseId":"56FKoT-Mod-1-US-1-TC-1",
  //      "TestCaseName":" Loan Application Form Submission",
  //      "updatedtcs":[],
  //      "updatedreftcs":[],
  //      "TestSteps":["Navigate to the bank's website.", 'Locate and access the loan application form.\\', 'Fill out the loan application form w...lication form.\\', 'Verify that a confirmation message is displayed indicating that the loan application has been received.'],
  //      "ref_tc":{
  //         "ExpectedResults":"['The loan application form should include fields for personal information, employment details, and loan amount requested.', ...early labeled and easy to understand.', 'The loan application form should capture all information accurately and completely.']",
  //         "TestCaseDescription":"This test case verifies that the loan application form includes fields for personal information, employment details, and loan amount requested. It ensures that users can enter all required information accurately and completely.",
  //         "TestCaseId":"0pA8vv-Mod-1-US-1-TC-2",
  //         "TestCaseName":" Loan Application Form Fields",
  //         "TestSteps":['Navigate to the loan application form.', 'Enter personal information, employment details, and loan amount requested.', 'Submit the loan application form.', 'Verify that all information is correctly captured and displayed.']
  //      }
  //   },
  //   {
  //      "ExpectedResults":"['The loan application should be successfully submitted after the user has acknowledged the loan terms and conditions.']",
  //      "SimilarityScore":0.9460852146148682,
  //      "TestCaseDescription":"This test case verifies that the loan application can be successfully submitted after the user has acknowledged the loan terms and conditions. It ensures that users can apply for the loan after reviewing the terms and conditions.",
  //      "TestCaseId":"56FKoT-Mod-1-US-3-TC-3",
  //      "TestCaseName":" Loan Application Submission",
  //      "TestSteps":['1. Navigate to the loan application page.', '2. Enter all necessary information for the loan application.', '3. Acknowledge the loan terms and conditions.', '4. Submit the loan application.'],
  //      "ref_tc":{
  //         "ExpectedResults":"['The loan application form should include fields for personal information, employment details, and loan amount requested.', ...early labeled and easy to understand.', 'The loan application form should capture all information accurately and completely.']",
  //         "TestCaseDescription":"This test case verifies that the loan application form includes fields for personal information, employment details, and loan amount requested. It ensures that users can enter all required information accurately and completely.",
  //         "TestCaseId":"0pA8vv-Mod-1-US-1-TC-2",
  //         "TestCaseName":" Loan Application Form Fields",
  //         "TestSteps":['1. Navigate to the loan application page.','Navigate to the loan application form.', 'Enter personal information, employment details, and loan amount requested.', 'Submit the loan application form.', 'Verify that all information is correctly captured and displayed.']
  //      }
  //   }];
  //   tcDetails={

  //     "TestCaseId":"0pA8vv-Mod-1-US-1-TC-2",
   
  //     "TestCaseName":" Loan Application Form Fields",
   
  //     "TestCaseDescription":"This test case verifies that the loan application form includes fields for personal information, employment details, and loan amount requested. It ensures that users can enter all required information accurately and completely.",
   
  //     "TestSteps":"['Navigate to the loan application form.', 'Enter personal information, employment details, and loan amount requested.', 'Submit the loan application form.', 'Verify that all information is correctly captured and displayed.']",
   
  //     "ExpectedResults":"['The loan application form should include fields for personal information, employment details, and loan amount requested.', 'All fields should be clearly labeled and easy to understand.', 'The loan application form should capture all information accurately and completely.']"
   
  //  }
    
  buttonActive = this.buttonToggles.info;
  currenttc: any;
  
  toggleButton(button: string) {
    this.buttonActive = button;
  }
  onClickCard(tc: any)
  {
    this.currenttc=tc
  }
  onClickQualityCompanion(){
    this.botService.registerAgent('testcasequality');
    this.route.navigate(['qualitycompanion'])
  }
  OnClickOpen(actual:any,ref:any,i:any)
  {
    
    this.refTCStepsToHighlight=[];
    this.actualTCStepsToHighlight=[];
   this.stepsToHighlight= this.similarTCRES[i]['StepsToHighlight']
   let acTcId=this.similarTCRES[i]['TestCaseId'];
   this.currentUniqueWords=this.similarTCRES[i]['UniqueWords'];
  this.actualTCStepsToHighlight= this.similarTCRES[i]['StepsToHighlight'][acTcId];
 let refTcId=this.similarTCRES[i]['ref_tc']['TestCaseId'];
 this.refTCStepsToHighlight= this.similarTCRES[i]['StepsToHighlight'][refTcId];
    this.isOpen = !this.isOpen;
    this.currentActual=actual;
    this.currentRef=ref;
  }
  isWordHighlight(word: string) {
    return this.currentUniqueWords?.includes(word);
  }
  closeModal(){
    this.isOpen = !this.isOpen;
  }
  initializeWebSocketConnection() {
    console.log('Initializing WebSocket connection');
    this.botService.registerAgent('testcasequality');
  }
  similarTcModification()
  {
    console.log(this.similarTCRES,"initial");
    
    this.similarTCRES.forEach((element:any) => {
      element.SimilarityScore=Math.round(element.SimilarityScore*10000)/100;
      
    //  element.updatedtcs=this.getUpdatedTcs(element.TestSteps,element.ref_tc.TestSteps);
     // element.TestSteps=this.parsingStringToArray(element.TestSteps);  
  //  element.ref_tc.TestSteps=this.parsingStringToArrayRR(element.ref_tc.TestSteps); 
    });
  //  this.similarTCRES=this.similarTCRES.filter((element:any)=>element.TestSteps!=false && element.ref_tc.TestSteps!=false);
    console.log(this.similarTCRES,"final");
  }
  parsingStringToArray(data:any)
  {
    let val=true;
    let dt = data
        .replace(/'([^']+)'/g, '"$1"');  
        
      try{
        dt= JSON.parse(dt);

      console.log(dt)
      }catch(e)
      {
        val=false;
       
        console.log(e);
        return false;
      }
      return dt;
  }
  parsingStringToArrayRR(data:any)
  {
    let val=true;
    let dt = data.slice(1,-1)
        .replace(/'([^']*)'/g, '"$1"');  
        
      try{
        dt= JSON.parse('dt');

      console.log(dt)
      }catch(e)
      {
        val=false;
       
        console.log(e);
        return false;
      }
      return dt;
  }
  getUpdatedTcs(tcs:any,refTcs:any)
  
  {
    let updated:any=[];
    tcs.forEach((element:any) => {
      if(this.Status(element,refTcs))
      {
        updated.push(element);
      }
      else{
        updated.push('empty');
      }
    });
    return updated;
  }
  Status(step:any,tcs:any)
  {
    let status=false;
    if(this.actualTCStepsToHighlight?.length)
    {
      tcs?.forEach((element:any) => {
        if(element==step)
        {
          status=true;
        }
      });
    }
   
    return status;
  }
  splitStr(content: String) {
     highlighted: String;
     rest: String;
   const [highlighted, ...rest] = content.split(':');
    return { highlighted, rest: rest.join(':') };
  }
  onClickAskYourBuddy() {
    // console.log('ask your buddy');
    this.route.navigate(['/askyourbuddy']);
  }
  refreshData() {
    // console.log('refresh');
  }
  onClickworkcompanion(){
    this.route.navigate([''])
  }
}
export interface PeriodicElement {
  Similar_TC_IDName: string;
  TC_Description: number;
  SimilarityScore: number;
  Differences: string;
}
