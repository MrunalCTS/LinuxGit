import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AbstractControl, CheckboxRequiredValidator, FormArray, FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatRippleModule } from '@angular/material/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { BotWebSocketService } from '../bot-websocket.service';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
// import { BrowserModule } from '@angular/platform-browser'
import { MatSort } from '@angular/material/sort';
import { Subject } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ShowtestdataComponent } from '../showtestdata/showtestdata.component';
import { SelectionModel } from '@angular/cdk/collections';
@Component({
  selector: 'app-data2',
  standalone: true,
  imports: [
    // BrowserModule,
    RouterModule,
    CommonModule,
    FormsModule,
    MatGridListModule,
    MatCardModule,
   MatIconModule,
   MatFormField,
   MatGridListModule,
   MatGridListModule,
   MatCardModule,
   MatDialogModule,
   MatTabsModule,
   MatIconModule,
   MatFormFieldModule,
   MatInputModule,
   MatButtonModule,
   MatTableModule,
   MatRippleModule,
   MatCheckboxModule,
   MatButtonToggleModule,
   MatExpansionModule,
    ReactiveFormsModule,
    MatPaginator,
    MatPaginatorModule
   ],
   schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './data2.component.html',
  styleUrl: './data2.component.css'
})

export class Data2Component implements OnInit,OnDestroy,AfterViewInit{
 
  selectedOptions: any[] =[];
  checkedval: any=[];
  chat: any;
  // chat: AbstractControl;
  isdisplay: boolean=false;
  displayedColumns: string[] = ['select','name','description'];
  displayedColumns1: any;
  checkedDataSource = new MatTableDataSource<any>();
  @ViewChild('paginator1', { static: true }) paginator1!: MatPaginator;
  @ViewChild('paginator2',{static:true}) paginator2!: MatPaginator;
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;
  @ViewChild('chatContainer', { static: false })
  private chatContainer!: ElementRef;
  private stop$ = new Subject<void>();
  socket: WebSocket;
  checkboxClicked: boolean=false;
  checkboxOrRadioButtonClicked: boolean=false;
  dataSource1 = new MatTableDataSource<PeriodicElement>;
  dataSource = new MatTableDataSource<any>();
  selection = new SelectionModel<PeriodicElement>(true, []);
  isSubmitDisabled: boolean=false;
  downloadLinks: {url: string; fileName: string}[] = [];
  // dataSource = ELEMENT_DATA;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator1;
    this.dataSource1.paginator = this.paginator2;
    // this.checkedDataSource.paginator = this.paginator3;
    this.checkedDataSource.paginator = this.paginator
  }
  ngAfterViewChecked() {
    
   
   if (this.chatContainer && !this.checkboxClicked) {
      this.scrollToBottom()
      
     } 
    else if(this.checkboxClicked){
      this.checkboxClicked = true;
      // this.checkboxClicked=false;
     }
      else {
       console.error('chatContainer is not defined');
 
     }
     
   }
  scrollToBottom(): void {
    
    try {
      // console.log('Scrolling to bottom');
      // console.log('scrollHeight:', this.chatContainer.nativeElement.scrollHeight);
      // console.log('clientHeight:', this.chatContainer.nativeElement.clientHeight);
      this.chatContainer.nativeElement.scrollTop =
        this.chatContainer.nativeElement.scrollHeight;
    } catch (err) {
      // console.error('Scroll to bottom failed:', err);
    }
  }
  constructor(private fb:FormBuilder,private botService: BotWebSocketService,private router: Router,public dialog: MatDialog) {
    this.socket = new WebSocket(environment.websocketUrl);
   }
   openDialog(option: any): void {
    // console.log('option', option);
    const dialogRef = this.dialog.open( ShowtestdataComponent, {
      height: "calc(90% - 30px)",
      width: "calc(85% - 30px)",
      maxWidth: "95%",
      maxHeight: "95%",
      data: { option }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // console.log(`Dialog result: ${result}`);
    });
  }
  userInput = new FormControl('');
  directoryData: any;
  buttonToggles = {
    info: 'info',
    links: 'links',
    docs: 'docs',
    media: 'media',
  };
  isChatBotLoading = false;
  buttonActive = this.buttonToggles.info;
  agentId: string = 'testdatageneration';
  ngOnInit(): void {
    // Register an agent when the component initializes
    // this.router.events.pipe(
    //   filter(event => event instanceof NavigationEnd)
    // ).subscribe(() => {
    //   this.initializeWebSocketConnection();
    // });
    this.initializeWebSocketConnection();
    // this.initializeWebSocketConnection();
    
    this.mainForm = this.fb.group({
      ChatArray: this.fb.array([]),
    });

    // Listen for messages from the server
    this.botService.setOnMessageHandler((event) => {
      this.isChatBotLoading = false;
      console.log(event);
      const data = JSON.parse(event.data);
      if (data !== undefined && data !== null) {
        this.chatContentForm(data);
      }
     
    });
    // this.dataSource1.paginator = this.paginator;
    // this.dataSource1=new MatTableDataSource<PeriodicElement>;
    this.dataSource.paginator = this.paginator1;
    this.dataSource1.paginator = this.paginator2;
    // this.checkedDataSource.paginator = this.paginator3;
    this.checkedDataSource.paginator = this.paginator
  }
 
  ngOnDestroy(): void {
    // console.log('Destroying component');
    this.botService.closeConnection();
    this.stop$.next();
    this.stop$.complete();
  }
  initializeWebSocketConnection() {
    console.log('Initializing WebSocket connection');
    this.botService.registerAgent('testdatageneration');
  }
  // ngOnInit(): void {
  //   this.mainForm = this.fb.group({
  //     ChatArray: this.fb.array([]),
  //   });
  //   this.chatContentForm(this.data);
  //   console.log(this.mainForm)
  // }
  mainForm!: FormGroup;y=[]
  data:any={}
  chatContentForm(data:any)
  {
    let cForm = this.fb.group({
      chatContent: this.fb.array([]),
      type: new FormControl(null),
      chatHeading: new FormControl(null),
      selectedOption: new FormControl([]),
      widget: new FormControl(null),
      style: new FormControl(''),
      chatQuestion: new FormControl(null), // add this line
      userChat: new FormControl(),
      isDisplay: new FormControl(false),
      // bulletPointType:new  FormControl(''),
      loadingmsg: new FormControl(''),
    });
    cForm.controls['chatHeading'].setValue(data?.text);
    cForm.controls['widget'].setValue(data?.widget);
    cForm.controls['type'].setValue(data?.type);
    cForm.controls['style'].setValue(data?.style);
    cForm.controls['loadingmsg'].setValue(data?.loadingmsg);
    const chatContentArray = cForm.get('chatContent') as FormArray;

    chatContentArray.clear();
    if (data.widget == 'welcomewidget') {
      data.value.forEach((val: any) => {
        const group = new FormGroup({
          // isSelected:new FormControl(false),
          text: new FormControl(val),
        });

        chatContentArray.push(group);
      });
    }
    if (data.widget == 'tracewidget') {
      cForm.controls['chatHeading'].setValue(data.value)
    }
    if (data.widget == 'yesnowidget') {
      
      //cForm.addControl('chatQuestion', new FormControl(data.text));
      data.value.forEach((val: any) => {
      const group = new FormGroup({
        //isEditableMode: new FormControl(false),
        text: new FormControl(val),
        // selectedOptionRbtn:new FormControl('')
      });

      chatContentArray.push(group);
    })
    }
    if (data.widget == 'editandsubmit') {
      data.value.forEach((val: any) => {
        const group = new FormGroup({
          name:new FormControl(val.Name),
        description:new FormControl(val.Description),
        // selected: new FormControl(false),
        });

        chatContentArray.push(group);
      });
      this.getDataSource1(cForm);
    }
    if (data.widget === 'display' && data.type === 'displaytable') {
      const tableDataArray = this.fb.array([]);
      data.value.forEach((dt: any, i: any) => {
        
        this.displayedColumns1=Object.keys(dt)
        let data:any={};
         Object.entries(dt).forEach(d=>{
          
          // let test=new FormGroup({
          //   [d[0]]:new FormControl(d[1])  
          // })
         let test1={[d[0]]:d[1]};
         
         data={...data,...test1};
      

        })
        tableDataArray.value.push(data);
       
    //   Object.keys(dt).forEach((d) => {
            
    //     let keyControl = new FormControl(dt);
    //     let group = new FormGroup({
    //       key: keyControl,
    //       [d]:new FormControl(dt[d]),
    //  //     val: this.editAndSubmitArray(dat[itr][dt]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
    //     });
    //     chatContentArray.push(group);
    //   })
      // Push the FormArray into chatContentArray
    ;
    })
    chatContentArray.push(tableDataArray);
        this.dataSource.data = tableDataArray.value;
        //  console.log("FORM", this.mainForm)
    }
    
    
  if(data.widget === 'display' && data.type === 'testcaseaccordion'){
    // const tcAccordianArray = new FormArray<FormControl<any>>([]);
    
    // data.value.forEach((val: any) => {
    //   const tcAccordianArray=new FormGroup({
    //     tcName: new FormControl(val.tc.tcname),
    //     tcSteps: new FormControl(val.tc.tcSteps),
    //     tcExpected: new FormControl(val.tc.tcExpected),
    //   });
   
    data.value.forEach((val: any) => {
      chatContentArray.push(new FormControl(val));
      // console.log("chatContentArray", chatContentArray);
    });

        
      }
  
  
     if (data.type == 'dict') {
    data.val=  [{"fieldName":"d1","rule":"r1","type":"t1"},{"fieldName":"d2","rule":"r2","type":"t2"}];
    data?.val.forEach((dt: { feild: any; type: any; rule: any; })=>{
      let group= new  FormGroup   ({
        feild:new FormControl(dt.feild),
        type:new FormControl(dt.type),
        rule:new FormControl(dt.rule)
      });
      chatContentArray.push(group);
    });
  
   }
  let chats = this.mainForm.get('ChatArray') as FormArray;
  chats.push(cForm);

  if (data.widget === 'display' && data.type === 'download') {
    console.log('Download data:', data);
    const filePath = data.value[0].filepath;
    const fileName = data.value[0].filename;
    const fileBlob = data.value[0].filedata;
    console.log("fileblob", fileBlob);
    let mimeType = 'application/octet-stream';
    if (fileName.endsWith('.csv')) {
      mimeType = 'text/csv';
    } else if (fileName.endsWith('.json')) {  
      mimeType = 'application/json';
    }

    const binary = atob(fileBlob);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const blob = new Blob([bytes], { type: mimeType });

    console.log('File blob:', blob);

    this.downloadBlob(blob, fileName);
  }
  
 
  }
  downloadBlob(blob: Blob, fileName: string): void {

    const url = URL.createObjectURL(blob);
    this.downloadLinks.push({url, fileName});
 
  }


  createDownloadLink(filePath: string, fileName: string): void {
    const link = document.createElement('a');
    link.href = filePath;
    link.textContent = fileName;
    link.target = '_blank';
    link.style.display = 'block';
    link.style.marginTop = '10px'; 
  
    

    // const preview = document.createElement('div');
    // preview.style.border = '1px solid #ccc';
    // preview.style.padding = '10px';
    // preview.style.marginBottom = '10px';
    // preview.style.maxHeight = '150px';
    // preview.style.overflow = 'auto';

    // const fileExtension = fileName.split('.').pop()?.toLowerCase();
    // console.log('Fetching file:', filePath);
    // if(fileExtension === 'csv' || fileExtension === 'json') {
      
    //   fetch(filePath)
    //     .then(response => response.text())
    //     .then((content) => {
    //       const snippet = document.createElement('pre');
    //       snippet.textContent = this.getFileSnippet(content, fileExtension);
    //       preview.appendChild(snippet);
    //     })
    //     .catch((error) => {
    //       console.error('Error fetching file:', error);
    //     });
    // }else{
    //   preview.textContent = 'Preview not available for this file type';
    // }
    const container = document.getElementById('download-container');
    container?.appendChild(link);
    // container?.appendChild(preview);
  }

  getFileSnippet(content: string, fileType: string): string {
    if (fileType === 'csv') {
      return content.split('\n').slice(0, 5).join('\n');
    }else if(fileType === 'json') {
      try{
        const json = JSON.parse(content);
        return JSON.stringify(json, null, 2).split('\n').slice(0, 10).join('\n');
      }catch(error){
        console.error('Error parsing JSON:', error);
      }
      
    }
    return "Preview not available for this file type";
  }

  truncateFileName(fileName: string): string {
    const maxLength = 20;
    if (fileName.length > maxLength) {
     const ext = fileName.substring(fileName.lastIndexOf('.'));
     return fileName.substring(0, maxLength - ext.length) + '...' + ext;
    }
    return fileName;
  }

  getChatContentControls(chat: AbstractControl): any[] {
    
    const chatContent = (chat as FormGroup).get('chatContent') as FormArray;
    return chatContent ? chatContent.controls : [];
  }
  getDataSource1(chat:any){
    const chatContent = (chat as FormGroup).get('chatContent') as FormArray;
    // this.dataSource1.data = chatContent.value;
    this.dataSource1=new MatTableDataSource<PeriodicElement>(chatContent.value);
    return this.dataSource1;
  }
  getChatContControls(): AbstractControl[] {
    // Assuming you have a formGroup which contains the 'chatContent' FormArray
    const chatFormGroup = this.mainForm.get('ChatArray') as FormGroup; // Adjust based on your form structure
    const chatContentArray = chatFormGroup.get('chatContent') as FormArray;
    return chatContentArray ? chatContentArray.controls : [];
  }
  get chatsArray() {
    return this.mainForm.controls['ChatArray'] as FormArray;
  }
  isArray(obj: any): boolean {
    return Array.isArray(obj)
  }
  toggleExpanded(item: any) {
    item.expanded = !item.expanded;
  }
  toggleButton(button: string) {
    this.buttonActive = button;
  }
  submit(val: any) {
    this.isSubmitDisabled = true;
    // console.log("val",this.isSubmitDisabled);
    this.isChatBotLoading = true;
    const userChoice = this.userInput.value;

    // const userChoice = this.userMessage;
    this.botService.sendMessage({
     
      "userStoryId": userChoice,
    });
    
  }
  onSubmit(val:any)
  {
  //  console.log("val",val);
    this.isChatBotLoading = true;
    this.isdisplay=true;
    this.checkboxClicked=false;
    
    this.botService.sendMessage({
     
      "checked": val,
    });

  }
  getCheckedControls(data: any[]): any[] {
    return data.filter(option => option.checked);
  }

  onCheckboxChange(event: any, option: any,chat:any): void {
    // console.log("event",event,option,chat);
    option.selected = event.checked;
   
    
    if (event.checked) {
      
      chat.value.selectedOption.push(option);
      
     // this.selectedOptions.push(option);
    } else {
      
      const index = chat.value.selectedOption.indexOf(option.value);
      if (index > -1) {
        chat.value.selectedOption.splice(index, 1);
      }
    }
   
    this.checkedDataSource.data = chat.value.selectedOption;
    // console.log("checkedDataSource",this.checkedDataSource.data,chat.value.selectedOption);
   
  }
  onCheckboxOrRadioButtonClick() {

    this.checkboxClicked = true;
    
    // !this.chatContainer;
   
  }
  onSelectYesNO( chatForm: any, event: any) {
   
    this.isChatBotLoading = true;
    chatForm.controls['isDisplay'].setValue(true);
    chatForm.controls['selectedOption'].setValue(event.target.value);
    this.botService.sendMessage({ user_choice: event.target.value });
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource1.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
// if(event.checked){

// }
this.selection.select(...this.dataSource1.data);
this.checkedDataSource.data = this.selection.selected;
// console.log("datasource1",this.dataSource1.data);
    // console.log("selected data",this.selection.select(...this.dataSource1.data),this.checkedDataSource.data);

  }

  /** The label for the checkbox on the passed row */
  // checkboxLabel(row?: PeriodicElement): string {
  //   if (!row) {
  //     return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
  //   }
  //   return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  // }
  // isAllSelected(): boolean {
  //   const numSelected = this.selectedOptions.length;
  //   const numRows = this.chatsArray.length;
  //   return numSelected === numRows;
  // }

  // isIndeterminate(): boolean {
  //   return this.selectedOptions.length > 0 && !this.isAllSelected();
  // }

  // masterToggle(): void {
  //   if (this.isAllSelected()) {
  //     this.selectedOptions = [];
  //   } else {
  //     this.selectedOptions = [...this.chatsArray.value];
  //   }
  // }


  // getSelectedOptions(): any[] {
  //   return this.selectedOptions;
  // }
}
// export interface PeriodicElement {
//   name: string;
//  description:string;
// }
// const ELEMENT_DATA: any[] = [];
export interface PeriodicElement {
  // selected:boolean;
  name: string;
 description:string;
}
