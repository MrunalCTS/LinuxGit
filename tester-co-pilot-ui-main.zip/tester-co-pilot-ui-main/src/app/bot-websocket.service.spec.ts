import { TestBed } from '@angular/core/testing';

import { BotWebsocketService } from './bot-websocket.service';

describe('BotWebsocketService', () => {
  let service: BotWebsocketService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BotWebsocketService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
