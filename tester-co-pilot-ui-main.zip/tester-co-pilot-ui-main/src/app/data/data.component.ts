import { Component, ViewChild, ElementRef, AfterViewChecked, Inject, PLATFORM_ID, signal, OnInit, inject, OnDestroy } from '@angular/core';
import { AbstractControl, Form, FormArray, FormBuilder, FormsModule } from '@angular/forms';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { BotWebSocketService } from '../bot-websocket.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogContentExampleDialogComponent } from '../dialog-content-example-dialog/dialog-content-example-dialog.component';
import { HttpClient } from '@angular/common/http';
import { interval, of, Subject } from 'rxjs';
import { catchError, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { EditorModule } from 'primeng/editor';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
@Component({
  selector: 'data-root',
  standalone: true,
  // Mark this component as standalone
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css'],
  imports: [
    RouterModule,
    CommonModule,
    FormsModule,
    MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatTabsModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatButtonToggleModule,
    MatExpansionModule,
    ReactiveFormsModule,
    MatListModule,
    EditorModule,
    DialogContentExampleDialogComponent
  ],
  // Use FormsModule directly in the component
})
export class DataComponent implements OnInit, OnDestroy {
  chatForm!: FormGroup;
  mainForm!: FormGroup;
  selectedradioOption: any;
  submittedArr: any = [];
  @ViewChild('chatContainer', { static: false })
  private chatContainer!: ElementRef;
  @ViewChild('webchat', { static: false }) webchatElement!: ElementRef;
   isBrowser: boolean;
  readonly panelOpenState = signal(false);
  title = 'Bot WebSocket Client';
  selectedCheckboxes: boolean[] = [];
  selectedRadio: boolean[] = [];
  userMessage: string = '';
  testCasesCheckboxes: any = [];
  testCasesRadio: any = [];
  // botMessages: string[] = [];
  botMessages: any = [];
  userID:any='';
  //  socket: WebSocket=new WebSocket(environment.websocketUrl);
  question: string = '';
  agentId: string = 'agent_1';
  result: any;
  messageType: any;
  response: any;
  userInput = new FormControl('');
  checkboxOrRadioButtonClicked:boolean = false;
  testcaselistcount: any;
  testcopilottextdata: any;
  directoryData: any;
  // longText = `The Chihuahua is a Mexican breed of toy dog. It is named for the
  // Mexican state of Chihuahua and is among the smallest of all dog breeds. It is
  // usually kept as a companion animal or for showing.`;
   public url = 'http://10.120.101.34:3136/gettestercopilotcontext';
  private stop$ = new Subject<void>();
  // myForm = new FormGroup({
  //   myControl: new FormControl('Userstory description: As an employee, I want to apply for sabbatical leaves in my leave management system')
  // });

  buttonToggles = {
    info: 'info',
    links: 'links',
    docs: 'docs',
    media: 'media',
  };
  isChatBotLoading = false;

  buttonActive = this.buttonToggles.info;
  checkboxClicked: boolean=false;
  socket: WebSocket;


  // directoryData = [
  //   {
  //     title: 'User Story & Acceptance Criteria',
  //     children: [
  //       {
  //         title: 'User Story & Acceptance Criteria',
  //         text: 'loreum ipsum dolor sit amet loreum ipsusadasm dolor sit dolor sit amet loreum ipsum dolor sit amet',
  //         expanded: false,
  //       }
  //     ],
  //     expanded: false,
  //   }
  // ];

  constructor(
    private botService: BotWebSocketService,
    private sanitizer: DomSanitizer,private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object,
    private fb: FormBuilder,
    public dialog: MatDialog, private http: HttpClient
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    // const WEBSOCKET_URL = 'ws://localhost:8080'; 
    this.socket = new WebSocket(environment.websocketUrl);
    // this.socket = new WebSocket(WEBSOCKET_URL);
    this.connectToWebSocket();
    // this.botService.registerAgent('run_graph');
   // Add a subscribe to complete the observable chain
    // this.gettestercopilottext();
  }
  openDialog(option: any): void {
    console.log('option', option);
    const dialogRef = this.dialog.open(DialogContentExampleDialogComponent, {
      height: "calc(90% - 30px)",
      width: "calc(85% - 30px)",
      maxWidth: "95%",
      maxHeight: "95%",
      data: { option }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      // console.log(`Dialog result: ${result}`);
    });
  }
  ngOnInit(): void {
    // Register an agent when the component initializes
    // console.log("",this.botService)
    
    // this.botService.registerAgent('testcasecreation');
    // this.router.events.pipe(
    //   filter(event => event instanceof NavigationEnd)
    // ).subscribe(() => {
    //   this.initializeWebSocketConnection();
    // });

    // this.initializeWebSocketConnection();
    this.botService.registerAgent('run_graph');
    
    this.mainForm = this.fb.group({
      ChatArray: this.fb.array([]),
    });
    // Listen for messages from the server
    this.botService.setOnMessageHandler((event) => {
      this.isChatBotLoading = false;
    console.log("",event);
      const data = JSON.parse(event.data);
      // console.log("data",data)
      if (data !== undefined && data !== null) {
        this.chatContentForm(data);
      }
    });
    
  }
  
  ngOnDestroy(): void {
    // console.log('Destroying component');
    this.botService.closeConnection();
    this.socket.close();
    this.stop$.next();
    this.stop$.complete();
  }
  // initializeWebSocketConnection() {
  //   console.log('Initializing WebSocket connection...');
  //   this.botService.registerAgent('run_graph');
  // }
  // Method to initialize WebSocket connection
  private connectToWebSocket(): void {
  //  if(this.socket)
  //  {
  //   this.socket.close();
  //  }
  //  this.socket = new WebSocket(environment.websocketUrl);
    // Listen for incoming WebSocket messages
    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log('data', data);
      // this.botMessages.push(`Bot: ${data.text}`);
      if (data.text.includes('result')) {
        // console.log('result');
        const datatext = data.text;
        const datajson = JSON.parse(datatext);
        // console.log('datatexttype', datatext);
        if (datajson.type === 'TEXT') {
          this.botMessages.push({
            type: 'TEXT',
            value: `Bot: ${datajson.result}`,
          });
        }
        if (datajson.type === 'LIST - Checkbox') {
          if (/\n\d+/.test(datajson.result)) {
            // If the string contains newline followed by a number, split it into test cases
            this.testCasesCheckboxes = datajson.result
              .split(/\n\d+\./)
              .slice(1);
          } else {
            // If the string does not contain newline followed by a number, push the whole string into testCases
            this.testCasesCheckboxes = [datajson.result];
          }
          //this.updateTestCasesCheckboxes('checkbox', this.testCasesCheckboxes);
          // this.testCases = datajson.result.split(/\n\d+\./).slice(1); // Use slice(1) to remove the first element which is the "Here is the list of test cases:" string
          // console.log('testCasesCheckbox', this.testCasesCheckboxes);
          this.selectedCheckboxes = Array(this.testCasesCheckboxes.length).fill(
            false
          ); // Initialize all checkboxes to false
          this.botMessages.push({
            type: 'CHECKBOX',
            value: `Bot: ${datajson.result}`,
            testCasesCheckboxes: this.testCasesCheckboxes,
          });
        }
        if (datajson.type === 'LIST - Radio') {
          if (/\n\d+/.test(datajson.result)) {
            // If the string contains newline followed by a number, split it into test cases
            this.testCasesRadio = datajson.result.split(/\n\d+\./).slice(1);
          } else {
            // If the string does not contain newline followed by a number, push the whole string into testCases
            this.testCasesRadio = [datajson.result];
          }
          //this.updateTestCasesCheckboxes('radiobutton', this.testCasesRadio);
          // this.testCases = datajson.result.split(/\n\d+\./).slice(1); // Use slice(1) to remove the first element which is the "Here is the list of test cases:" string
          // console.log('testCasesRadioButton', this.testCasesRadio);
          this.selectedRadio = Array(this.testCasesRadio.length).fill(false);
          this.botMessages.push({
            type: 'RADIO',
            value: `Bot: ${datajson.result}`,
            testCasesRadio: this.testCasesRadio,
          });
        }
      } else {
        
        this.botMessages.push({ type: 'BOT', value: `Bot: ${data.text}` }); // Append bot's response to messages array
        console.log('botMessages', this.botMessages);
      }
      console.log('Received message:', data, data.text);
    };

    // Log when WebSocket is successfully connected
    this.socket.onopen = () => {
      console.log('WebSocket connection opened.');
    };

    // Handle WebSocket errors
    this.socket.onerror = (error) => {
      console.error('WebSocket error occurred: ', error);
    };

    // Automatically reconnect if WebSocket is closed
    this.socket.onclose = () => {
      console.log('WebSocket connection closed. Reconnecting...');
      setTimeout(() => this.connectToWebSocket(), 1000); // Reconnect after 1 second
    };
  }
  public setSocket(value: any): void {
    this.socket = value;
  }
  replaceNewlines(testCase: string): SafeHtml {
    const text = testCase.replace(/\n/g, '<br />');
    return this.sanitizer.bypassSecurityTrustHtml(text);
  }
  updateTestCasesCheckboxes(type: string, newTestCases: string[]) {
    if (type === 'checkbox') {
      this.testCasesCheckboxes = [...this.testCasesCheckboxes, ...newTestCases]; // Add new test cases to the existing ones
      
    } else {
      this.testCasesRadio = [...this.testCasesRadio, ...newTestCases]; // Add new test cases to the existing ones
     
    }
  }
 
  onSubmit(value: any) {
  
    const selectedTestCasesCheckboxes = this.testCasesCheckboxes.filter(
      (testCase: any, i: any) => this.selectedCheckboxes[i]
    );
   
    const selectedTestCasesRadio = this.testCasesRadio.filter(
      (testCase: any, i: any) => this.selectedRadio[i]
    );
    
    if (value.type === 'CHECKBOX') {
      console.log(selectedTestCasesCheckboxes); // Replace this with your actual submission logic
      this.userMessage = selectedTestCasesCheckboxes.join('\n');
      this.sendMessage();
    } else {
      this.userMessage = selectedTestCasesRadio.join('\n');
      this.sendMessage();
      // Replace this with your actual submission logic
    }
  }

  onCancel(value: any) {
    if (value === 'CHECKBOX') {
      this.selectedCheckboxes = [];
    } else {
      this.selectedRadio = []; // Clear the selection
    }
  }
  ngAfterViewChecked() {
    
   if(this.checkboxClicked){
    this.checkboxOrRadioButtonClicked = true;
    this.checkboxClicked=false;
   }
    else if (this.chatContainer && !this.checkboxOrRadioButtonClicked) {
     this.scrollToBottom()
     
    } 
    else if (this.checkboxOrRadioButtonClicked) {
      this.checkboxOrRadioButtonClicked = false;
      
    }
     else {
      console.error('chatContainer is not defined');

    }
    
  }
 
  // Method to send user message to the bot
  sendMessage(): void {
    console.log('Sending message:', this.userMessage);
    if (this.userMessage.trim()) {
      // Append user's message to the chat box
      this.botMessages.push({ type: 'YOU', value: `You: ${this.userMessage}` });
      // this.botMessages.push(`You: ${this.userMessage}`);

      // Send message to the bot via WebSocket
      const payload = {
        type: 'message',
        text: this.userMessage,
      };

      if (this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify(payload));
      } else {
        console.error('WebSocket is not open. Cannot send message.');
      }

      // Clear the input field
      this.userMessage = '';
    }
  }
  openPopupSubmit(chat:any): void {
    
this.isChatBotLoading = true;

const userChoice = this.userInput.value; 
// const userChoice = this.userMessage;
this.botService.sendMessage({
  // event: 'run_graph',
  // agent_id: this.agentId,
  userStoryId: userChoice,
  // action: val,
});


   
  }
  scrollToBottom(): void {
    try {
      // console.log('Scrolling to bottom');
      // console.log('scrollHeight:', this.chatContainer.nativeElement.scrollHeight);
      // console.log('clientHeight:', this.chatContainer.nativeElement.clientHeight);
      this.chatContainer.nativeElement.scrollTop =
        this.chatContainer.nativeElement.scrollHeight;
    } catch (err) {
      console.error('Scroll to bottom failed:', err);
    }
  }
  onClickClose(){
    window.location.reload();
  }
  sendResponse() {
    const userChoice = this.userMessage;
    this.botService.sendMessage({
      event: 'user_response',
      agent_id: this.agentId,
      user_choice: userChoice,
    });
  }

  parseAndSetResponse(response: string): void {
    // debugger
    try {
      const cleanedResponse = response

        .replace(/\n/g, '\\n') // Escape newline characters

        .replace(/\t/g, '\\t') // Escape tabs

        .replace(/\\/g, '\\\\'); // Escape backslashes
      const parsedResponse = JSON.parse(cleanedResponse);

      this.response = parsedResponse.result || '';

      this.messageType = parsedResponse.type || '';
      console.log('parsed...', this.response, 'msg type....', this.messageType);
      this.response = this.response
        .replace(/\\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    } catch (error) {
      console.error('Error parsing response:', error);
    }
  }

  chatContentForm(data: any, userChat: boolean = false) {
    let cForm = this.fb.group({
      chatContent: this.fb.array([]),
      type: new FormControl(null),
      chatHeading: new FormControl(null),
      selectedOption: new FormControl(null),
      widget: new FormControl(null),
      style: new FormControl(''),
      chatQuestion: new FormControl(null), // add this line
      userChat: new FormControl(userChat),
      isDisplay: new FormControl(false),
      // bulletPointType:new  FormControl(''),
      loadingmsg: new FormControl(''),
    });

    cForm.controls['chatHeading'].setValue(data.text);
    cForm.controls['widget'].setValue(data.widget);
    cForm.controls['type'].setValue(data.type);
    cForm.controls['style'].setValue(data.style);
    cForm.controls['loadingmsg'].setValue(data.loadingmsg);
    const chatContentArray = cForm.get('chatContent') as FormArray;
    // console.log("chatContentArray",chatContentArray)

    chatContentArray.clear();

    if (userChat) {
      cForm.controls['selectedOption'].setValue(data.selectedOption);
    }
    // @ts-ignore
    if (data.widget == 'welcomewidget') {
      data.value.forEach((val: any) => {
        const group = new FormGroup({
          // isSelected:new FormControl(false),
          text: new FormControl(val),
        });

        chatContentArray.push(group);
      });
    }
    if (data.widget == 'tracewidget') {
      cForm.controls['chatHeading'].setValue(data.value)
    }
    if (data.type == 'nested-dict' && data.widget == 'editandsubmit') {

      let dt = data.value
        .replace(/\n/g, '')

        .replace(/\t/g, '')

        .replace(/\\/g, '');
      let dat = JSON.parse(data.value);
      // dat={   "existing_test_scenarios_to_be_updated": 
      //   [     "Employee successfully applies for sabbatical leave"   ],  
      //    "list_of_new_test_scenarios_to_be_created": { 
      //         "Positive Test Scenarios":
      //          [       "Employee follows the steps for applying for sabbatical leaves",    
      //              "Leave management system validates the application and provides a successful application confirmation to the employee", 
      //                    "HR Manager reviews and approves the employee's sabbatical leave request",   
      //                        "Leave management system validates the HR Manager's approval and provides a confirmation to the employee", 
      //                              "Employee's sabbatical leave request is recorded in the system",   
      //                                  "Employee's sabbatical leave request is marked as approved in the system"     ],   
      //                                    "Negative Test Scenarios": [       "Employee tries to apply for sabbatical leave without completing a minimum of 5 years of service",  
      //                                          "Employee tries to apply for sabbatical leave without providing a minimum notice period of 3 months"     ],  
      //                                             "Edge Test Scenarios": []   }}




      // Object.keys(dat).forEach((itr) => {
      //   let keyControl = new FormControl(itr);
      //   let group = new FormGroup({
      //     key: keyControl,
      //     val: this.editAndSubmitArray(dat[itr]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
      //   });
      //   chatContentArray.push(group);
      // });

      Object.keys(dat).forEach((itr) => {
        if(itr==='list_of_new_test_scenarios_to_be_created')
        {

          Object.keys(dat[itr]).forEach((dt) => {
            
            let keyControl = new FormControl(dt);
            let group = new FormGroup({
              key: keyControl,
              parentKey:new FormControl(itr),
              val: this.editAndSubmitArray(dat[itr][dt]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
            });
            chatContentArray.push(group);
          })

        }
        else{
          let keyControl = new FormControl(itr);
          let group = new FormGroup({
            key: keyControl,
            val: this.editAndSubmitArray(dat[itr]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
          });
          chatContentArray.push(group);
        }
        
      });
    }

    if (data.type == 'dict') {
      Object.entries(JSON.parse(data.value)).forEach((itr) => {
        if (data.style == 'bulletpoint') {
          let type = typeof itr[1];
          // cForm.controls['bulletPointType'].setValue(typeof(itr[1]));

          if (type == 'string' || type != 'object') {
            let group = new FormGroup({
              key: new FormControl([itr[0]]),
              val: new FormControl([itr[1]]),
              bulletPointType: new FormControl(type),
            });
            chatContentArray.push(group);
          }
          if (type == 'object') {
            let group = new FormGroup({
              key: new FormControl([itr[0]]),
              selectedBulletPoints: new FormControl(''),
              val: this.bulletPointsArr([itr[1]]),
              bulletPointType: new FormControl(type),
            });
            chatContentArray.push(group);
          }
        }
        else {
          let group = new FormGroup({
            key: new FormControl([itr[0]]),
            val: new FormControl([itr[1]]),
          });
          chatContentArray.push(group);
        }
        if (data.style == 'testcaseaccordion') {
         
          const itrAny: any = itr; // Fix: Explicitly type itr as any
          this.testcaselistcount = itrAny[1].length; // Fix: Use itrAny instead of itr
          // console.log('testcaselistcount', this.testcaselistcount);
        }
      });
    }
    if (data.type == 'display' || data.widget == 'contextDisplay') {
      Object.entries(data.value).forEach((itr) => {
        let group = new FormGroup({
          key: new FormControl([itr[0]]),
          val: new FormControl([itr[1]]),
        });
        chatContentArray.push(group);
      });
    }

    if (data.widget == 'yesnowidget') {
      cForm.addControl('chatQuestion', new FormControl(data.text));
      const group = new FormGroup({
        isEditableMode: new FormControl(false),
        text: new FormControl('Yes'),
        // selectedOptionRbtn:new FormControl('')
      });

      chatContentArray.push(group);
      const qgroup = new FormGroup({
        isEditableMode: new FormControl(false),
        text: new FormControl('No'),
        // selectedOption:new FormControl('')
      });

      chatContentArray.push(qgroup);
    }

    if (data.type == 'checkbox') {
     
      data.value.forEach((content: any) => {
        const group = new FormGroup({
          checked: new FormControl(false),
          isEditableMode: new FormControl(false),
          text: new FormControl(content),
        });

        chatContentArray.push(group);
      });
    }
    if (data.type == 'radiobtn') {
      data.chatContent.forEach((content: string) => {
        const group = new FormGroup({
          isEditableMode: new FormControl(false),
          text: new FormControl(content),
          // selectedOption:new FormControl('')
        });

        chatContentArray.push(group);
      });
    }

    
    let chats = this.mainForm.get('ChatArray') as FormArray;
    chats.push(cForm);
    //  let  chats=this.mainForm.get('ChatArray') as FormArray;
    //  chats.push(cForm)
    // console.log('this.mainForm', cForm);
  }
  onClickAdd(chatForm: any, arrName: any) {
  
    let formArray = chatForm.get(arrName) as FormArray;
  
    if (formArray) {
      const group = new FormGroup({
        checked: new FormControl(false),
        isEditableMode: new FormControl(false),
        text: new FormControl('Enter text here'),
      });
      formArray.push(group);
    } else {
      console.error(`No control found with the name ${arrName}`);
    }
    // console.log(chatForm);
    this.checkboxOrRadioButtonClicked=true;
  }
  onChangeText(option: any, sec: any) {
 

    option.controls['isEditableMode'].setValue(false)
   
  }
  get contentFormArray() {
    return this.chatForm.controls['chatContent'] as FormArray;
  }
  get chatsArray() {
    return this.mainForm.controls['ChatArray'] as FormArray;
  }
  onSelectYesNO(option: any, chatForm: any, event: any) {
    this.isChatBotLoading = true;
    chatForm.controls['isDisplay'].setValue(true);
    chatForm.controls['selectedOption'].setValue(event.target.value);
    this.botService.sendMessage({ user_choice: event.target.value });
  }
  // @ts-ignore
  onEditSubmit(chat, event, chatForm) {
    chatForm.controls['isDisplay'].setValue(true);
    chatForm.controls['selectedOption'].setValue(event.target.value);
    let scenerioData = {};
    
    let arr: any = [];
    let prev:any=''
    chat.value.chatContent.forEach((ct: any) => {
     
      if(prev!=='list_of_new_test_scenarios_to_be_created')
      {
         arr= [];
      }
   prev=ct.parentKey;
      if (Array.isArray(ct.val)) {
        ct.val.forEach((val: any) => {
          if (val.checked) {
            this.submittedArr = arr.push(val.text);
          }
        });
        
        if(ct.parentKey==='list_of_new_test_scenarios_to_be_created')
        {
          scenerioData = { ...scenerioData, [ct.parentKey]: arr };
        }
        else{
          scenerioData = { ...scenerioData, [ct.key]: arr };
        }
        
      }
    });
    this.botService.sendMessage({
      val: scenerioData,
      action: event.target.value,
    });
   this.checkboxOrRadioButtonClicked=false;

  }

  onEditSelect(chat: any, arrName: string) {
    // debugger
    chat.controls['isDisplay'].setValue(true);

    let formArray = chat.get(arrName) as FormArray;
    let arr: any = [];
    formArray.value.forEach((val: any) => {
      if (val.checked) {
        this.submittedArr = arr.push(val.text);
      }
    });
    this.botService.sendMessage({ checked: arr });
  // this.onCheckboxOrRadioButtonClick()
  }

  getChatContentControls(chat: AbstractControl): AbstractControl[] {
    const chatContent = (chat as FormGroup).get('chatContent') as FormArray;
    // console.log("chatContent",chatContent)
    return chatContent ? chatContent.controls : [];
  }
  getOptionValContentControls(option: AbstractControl): AbstractControl[] {
    const optioncontent = (option as FormGroup).get('val') as FormArray;
    
    return optioncontent ? optioncontent.controls : [];
  }

  onChangeEditText(chat: any) {
    let arr: any = [];
    chat.value.forEach((val: any) => {
      if (val.checked) {
        arr.push(val.text);
      }
    });
    this.botService.sendMessage({ checked: arr });
    
  }
  // @ts-ignore
  editAndSubmitArray(val: any): FormArray {
    let arr: FormGroup[] = [];
    val.forEach((itr: any) => {
      const group = new FormGroup({
        checked: new FormControl(false),
        isEditableMode: new FormControl(false),
        text: new FormControl(itr),
      });
      arr.push(group);
    });
    return new FormArray(arr);
  }

  onClickSubmit(val: any, chat: any) {
    chat.controls['selectedOption'].setValue(val);
  }

  bulletPointsArr(val: any): FormArray {
    let arr: FormGroup[] = [];
    val.forEach((itre: any) => {
      itre.forEach((itr: any) => {
        const group = new FormGroup({
          text: new FormControl(itr),
        });
        arr.push(group);
      });
    });
    return new FormArray(arr);
  }

  enableEditMode(option: any) {
    option.controls['isEditableMode'].setValue(true);
    this.checkboxOrRadioButtonClicked=true;
  }

  removeUnderScore(str: string[]) {
    let newstr = str[0].split('_').join(' ');
    
    return newstr;
  }

  formatString(chat: any, str: string) {
    switch (chat.value.style) {
      case 'bulletpoint':
        if (Array.isArray(str)) {
          str = str.reduce((acc, val) => acc + val, '');
        }
        str = str.replaceAll('\n', '<br><br>');
        break;
    }
    return str;
  }

  logger(...param: any[]) {
   
  }

  toggleButton(button: string) {
    this.buttonActive = button;
  }
  toggleExpanded(item: any) {
    item.expanded = !item.expanded;
  }
  onClickEdit() {
  
  }
  onProceed() {
  }
  handleSaveData(data: any) {
   
  }
  onCheckboxOrRadioButtonClick() {

    this.checkboxOrRadioButtonClicked = true;
    
    // !this.chatContainer;
   
  }
  oncheckboxClicked(){
    this.checkboxClicked=true;
  }
  isArray(obj: any): boolean {
    return Array.isArray(obj)
  }
  navigateHome(): void {
    this.router.navigate(['']);
  }

  // gettestercopilottext() {
  //   const TEN_SECONDS = 10000; // 10 seconds in milliseconds

  //   interval(TEN_SECONDS).pipe(
  //     startWith(0), // So that it runs immediately the first time
  //     switchMap(() => this.botService.gettestercopilottext()),
  //     catchError(error => {
  //       console.error('Error occurred:', error);
  //       return of(null); // Return a new Observable if an error occurs
  //     }),
  //     takeUntil(this.stop$) // Stop the interval when stop$ emits a value
  //   ).subscribe((response) => {
     
  //     if (response != "" && response != null && response.length > 0) {
  //       let element = response[0];
  //       this.directoryData = [
  //         {
  //           title: 'User Story & Acceptance Criteria',
  //           children: [
  //             {
  //               title: 'User Story',
  //               text: element.userstory_description,
  //               expanded: false,
  //             },
  //             {
  //               title: 'Acceptance Criteria',
  //               text: element.acceptance_criteria,
  //               expanded: false,
  //             }
  //           ],
  //           expanded: false,
  //         },
  //         {
  //           title: 'Business Rules & Existing Test Case Scenarios',
  //           children: [
  //             {
  //               title: 'Business Rules',
  //               text: element.business_rules,
  //               expanded: false,
  //             },
  //             {
  //               title: 'Existing Test Case Scenarios',
  //               text: element.existing_test_case_scenarios,
  //               expanded: false,
  //             }
  //           ],
  //           expanded: false,
  //         }
  //       ]
  //       this.stop$.next(); // Stop the interval
  //     }
  //     else {
  //      this.gettestercopilottext();
  //     }
  //   });
  // }
//   getFilteredOptions(chat:any) {
//     return chat.filter((option: { val: any[]; }) => 
//         option.val.some(val => val.checked)
//     );
// }

}
