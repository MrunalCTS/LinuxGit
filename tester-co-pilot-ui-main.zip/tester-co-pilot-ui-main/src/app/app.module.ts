import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';  // <-- Add this line
import {EditorModule} from 'primeng/editor';
import { AppComponent } from './app.component';
import { ChatComponent } from './chat/chat.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableDataSource } from '@angular/material/table';
import { DialogContentExampleDialogComponent } from './dialog-content-example-dialog/dialog-content-example-dialog.component';
import { HomeComponent } from './home/home.component';
 import {routes} from "./app.routes";
import { RouterModule, Routes } from '@angular/router';
import { DataComponent } from './data/data.component';
import { MatListModule } from '@angular/material/list';
import { CommonModule } from '@angular/common';
import { DataService } from './data.service';
import { Data2Component } from './data2/data2.component';
import { BotWebSocketService } from './bot-websocket.service';
import { CodeEditorModule } from '@acrodata/code-editor';
import { CodemirrorModule } from '@ctrl/ngx-codemirror';
import { CdkAccordionModule } from '@angular/cdk/accordion';
@NgModule({
    declarations: [
        AppComponent,
        DataComponent,
        ChatComponent,
        Data2Component,
        HomeComponent,
        DialogContentExampleDialogComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        EditorModule,
        MatIconModule,
        RouterModule,
        CommonModule,
        ReactiveFormsModule,
        MatListModule,
        RouterModule.forRoot(routes),
        MatGridListModule,
        MatCardModule,
        MatDialogModule,
        MatTabsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatRippleModule,
        MatButtonToggleModule,
        MatExpansionModule,
        MatPaginatorModule,
        MatCheckboxModule,
        CodeEditorModule,
        CodemirrorModule,
        CdkAccordionModule
        
    ],
    providers: [DataService,BotWebSocketService],
    bootstrap: [AppComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
