import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AskyourbuddyComponent } from './askyourbuddy.component';

describe('AskyourbuddyComponent', () => {
  let component: AskyourbuddyComponent;
  let fixture: ComponentFixture<AskyourbuddyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AskyourbuddyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AskyourbuddyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
