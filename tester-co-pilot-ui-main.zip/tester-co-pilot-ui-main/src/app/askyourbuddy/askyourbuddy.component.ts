import { Component, ElementRef, Injectable, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { Router } from '@angular/router';
import { BotWebSocketService } from '../bot-websocket.service';
import { environment } from '../../environments/environment';

// WebSocket URL for connecting to the Python bot server
const WEBSOCKET_URL = 'ws://10.120.100.136:9000';

@Component({
  selector: 'app-askyourbuddy',
  standalone: true,
  templateUrl: './askyourbuddy.component.html',
  styleUrl: './askyourbuddy.component.css',
  imports: [CommonModule, FormsModule, MatDividerModule, MatListModule, MatCardModule, MatInputModule, MatButtonModule, MatFormFieldModule,
    MatIconModule, MatButtonToggleModule
  ],
})
export class AskyourbuddyComponent implements OnInit,OnDestroy {
  title = 'Bot WebSocket Client';
  userMessage: string = '';
  botMessages: any = [];
  isChatBotLoading = false;
  selectedButton: string = 'Risk based testing';
  private stop$ = new Subject<void>();
  // recentSearches = [
  //   "give me 2 testcases for R_02 release",
  //   "give me user stories for R_04 release",
  //   "give me defects associated with testcase 3BbjjC-Mod-1-US-1-TC-3"
  // ];
  riskbasedtesting = [
    "Provide me the list of test cases associated with the user story 'vmOiEQ-Mod-1-US-1'",
    "List down all the core test cases for my application 'xyz'",
    "I am trying to test the important test cases as part of in-sprint test execution. Could you advise on the list of test cases for sprint#18?",
    "How many test cases are under risk category which i should consider for my release testing?"
  ]
  storysense = [
    "Provide me the average story quality for this release",
    "Can you list the existing acceptance criteria for US'123' and also provide additional recommended acceptance criteria?",
    "What category of story needs to be improved overall"
  ]
  defectsdata = [
    "Can you give me the user story for Defect id 'vmOiEQ-Mod-1-US-1-TC-1-DC-1'",
    "Provide me the test cases associated with the defect 'vmOiEQ-Mod-1-US-1-TC-1-DC-1'",
    "How many defects are  raised for the test case 'vmOiEQ-Mod-1-US-1-TC-1-DC-1'"
  ]
  metricdata = [
    "Give me the total defect count grouped by status",
    "Give me the execution status of test cases grouped for the current release",
    "How many defects are ageing more than 1 week",
    "Which user story is having maximum defects in this release"
  ]
  applicationTooldata = [
    "Provide me the applications which are using cypress as automation framework",
    "List down the Auto healing libraries used for Selenium across various application",
    "Provide me the downstream application components for eshopify application"
  ]
  onClickCategoryCommandPrompt: boolean = false;
  private socket: WebSocket;
  @ViewChild('chatContainer', { static: false })
  private chatContainer!: ElementRef;
  private messages: Subject<string> = new Subject<string>();
  constructor(private route: Router,private botService: BotWebSocketService) {
    // Initialize WebSocket connection when the component is created
    //this.socket = new WebSocket(WEBSOCKET_URL);
    this.socket = new WebSocket(environment.websocketUrl);
    this.connectToWebSocket();
  }
  ngOnInit(): void {
    console.log('Register Agent');
    this.botService.registerAgent('kgbot');
    this.botService.setOnMessageHandler((event) => {
    this.isChatBotLoading = false;
    console.log("",event);
      const data = JSON.parse(event.data);
      // console.log("data",data)
      if (data !== undefined && data !== null) {
        this.botMessages.push({ type: 'BOT', value: `${data.output}` });
        //this.chatContentForm(data);
      }
    });
  }
  ngOnDestroy(): void {
    console.log('Destroying component');
    this.botService.closeConnection();
    this.socket.close();
    this.stop$.next();
    this.stop$.complete();
  }
  ngAfterViewChecked() {
    if (this.chatContainer && !this.onClickCategoryCommandPrompt) {
      this.scrollToBottom();
    } else if (this.onClickCategoryCommandPrompt) {
      this.onClickCategoryCommandPrompt = false;
    }
    else {
      console.error('chatContainer is not defined');
    }
  }

  selectButton(button: string) {
    this.onClickCategoryCommandPrompt = true;
    this.selectedButton = button;
  }

  selectSearch(search: string) {
    this.onClickCategoryCommandPrompt = true;
    this.userMessage = search;
  }

  // Method to initialize WebSocket connection
  private connectToWebSocket(): void {
    this.socket.onmessage = (event) => {
      console.log('eventdata', event.data);
      const data = JSON.parse(event.data);
      console.log('data', data);
      this.botMessages.push({ type: 'BOT', value: `${data.text}` });
      console.log('BotMessage ', this.botMessages);
    };

    // Automatically reconnect if WebSocket is closed
    this.socket.onclose = () => {
      console.log('WebSocket connection closed. Reconnecting...');
      setTimeout(() => this.connectToWebSocket(), 1000);
    };
  }
  // Method to send user message to the bot
  sendMessage(): void {
    this.isChatBotLoading = true;
    if(this.isChatBotLoading=true){
      this.scrollToBottom();
    }
    
    if (this.userMessage.trim()) {
      // Append user's message to the chat box
      // this.botMessages.push(`You: ${this.userMessage}`);
      this.botMessages.push({ type: 'YOU', value: `${this.userMessage}` });
      // Send message to the bot via WebSocket
      this.botService.sendMessage({
        userinput: this.userMessage,
      });
      // const payload = {
      //   type: 'message',
      //   text: this.userMessage
      // };
      // this.socket.send(JSON.stringify(payload));

      // Clear the input field
      this.userMessage = '';
      this.scrollToBottom();
    }
  }
  scrollToBottom(): void {
    try {
      this.chatContainer.nativeElement.scrollTop =
        this.chatContainer.nativeElement.scrollHeight;
        // console.log('scroll to bottom');
    } catch (err) {
      console.error('Scroll to bottom failed:', err);
    }
  }
  refreshData() {
    // console.log('refresh');
  }
  formatString(messageval: any) {
    let resultval;

    if (messageval) {
      // console.log('typeof', typeof (messageval));
      let testCases = messageval;
      //console.log(testCases)
      //let testCases = "Here are two test cases:\n\n1. **Test Case Name:** vmOiEQ-Mod-1-US-1-TC-1\n   - **Description:** This test case verifies that the employee's personal information is displayed correctly on their profile page. It ensures that the employee's name, contact details, and job title are visible and accurate.\n\n2. **Test Case Name:** vmOiEQ-Mod-1-US-1-TC-2\n   - **Description:** This test case verifies that appropriate error messages are displayed when employee information is missing from their profile page. It ensures that the system prompts the HR manager to enter any missing information.";
      let resultval = testCases.replace(/\n/g, '<br>');

      // let converter = new showdown.Converter;
      // testCases = converter.makeHtml(testCases);
      // console.log('testCases', resultval);
      //let testCases = "Here are two test cases:\n\n1. **Test Case Name:** vmOiEQ-Mod-1-US-1-TC-1\n   - **Description:** This test case verifies that the employee's personal information is displayed correctly on their profile page. It ensures that the employee's name, contact details, and job title are visible and accurate.\n\n2. **Test Case Name:** vmOiEQ-Mod-1-US-1-TC-2\n   - **Description:** This test case verifies that appropriate error messages are displayed when employee information is missing from their profile page. It ensures that the system prompts the HR manager to enter any missing information.";
      // testCases = testCases.replace(/"/g, '');

      //  resultval= marked.parse(newline);
    }
    return resultval;
  }
  onClickworkcompanion(){
    this.route.navigate([''])
  }
  formatMessage(message: string): string {
    // Replace **heading** with <strong>heading</strong>
    let formattedMessage = message.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Replace \n with <br>
    formattedMessage = formattedMessage.replace(/\n/g, '<br>');
    return formattedMessage;
  }
  onClickQualityCompanion(){
    this.botService.registerAgent('testdatageneration');
    this.route.navigate(['qualitycompanion'])
  }
}
