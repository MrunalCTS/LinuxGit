import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DataComponent } from './data/data.component';
import { Data2Component } from './data2/data2.component';
import { AskyourbuddyComponent } from './askyourbuddy/askyourbuddy.component';
import { QualityCompanionComponent } from './quality.companion/quality.companion.component';
import { TestscriptgeneratorComponent } from './testscriptgenerator/testscriptgenerator.component';

export const routes: Routes = [

  { path: '', component: HomeComponent },
  { path: 'qualitycompanion', component: QualityCompanionComponent },
  { path: 'testcasecreation', component: DataComponent },
  { path: 'testdataprovisioning', component: Data2Component },
  { path: 'askyourbuddy', component: AskyourbuddyComponent },
  { path: 'testscriptgeneration', component: TestscriptgeneratorComponent},
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }