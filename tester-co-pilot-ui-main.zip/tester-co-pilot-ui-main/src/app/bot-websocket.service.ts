import { Injectable } from '@angular/core';
import { async, Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class BotWebSocketService {

  private socket: WebSocket | null = null;
  openPromise: Promise<void> | null = null;
  private messages: Subject<string> = new Subject<string>();
  // url = 'http://10.120.101.34:3136';

  constructor(private http: HttpClient) {
    this.connect();
  }

  private createWebSocket(): void {
    this.socket = new WebSocket(environment.websocketUrl);
    this.openPromise = new Promise((resolve, reject) => {
      this.socket!.onopen = () => {
        console.log('WebSocket connection established');
        resolve();
      }

      this.socket!.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log('Message from server: ', data);
      };

      this.socket!.onclose = () => {
        console.log('WebSocket connection closed');
      };

      this.socket!.onerror = (error) => {
        console.error('WebSocket error: ', error);
      };
    });
  }

  // Establish WebSocket connection
  private connect(): void {
    this.createWebSocket();
    this.socket = new WebSocket(environment.websocketUrl);

    this.openPromise = new Promise((resolve, reject) => {
      if (this.socket) {
        this.socket.onopen = () => {
        console.log('WebSocket connection established');
        resolve();
      };
    }
    });
    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log('Message from server: ', data);
      this.messages.next(data.text); // Send the received message to subscribers
    };

    this.socket.onclose = () => {
      console.log('WebSocket connection closed. Reconnecting...');
      setTimeout(() => this.connect(), 1000); // Auto-reconnect if the socket closes
    };
  }

  // Send a message to the bot
  // sendMessage(message: string): void {
  //   const payload = {
  //     type: 'message',
  //     text: message
  //   };
  //   this.socket.send(JSON.stringify(payload));
  // }

    private async ensureConnection(): Promise<void> {
      if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
        await this.connect();
      }
      await this.openPromise;
    }
  
    public async sendMessage(message: any): Promise<void> {
      await this.ensureConnection();
      console.log('Sending message: ', this.socket!.readyState, WebSocket.OPEN);
      if (this.socket!.readyState === WebSocket.OPEN) {
        this.socket!.send(JSON.stringify(message));
      } else {
        console.error('WebSocket is not open. Message not sent');
      }
    }
    async registerAgent(useCaseName: string) {
      await this.sendMessage({ event: useCaseName, agent_id: useCaseName });
    }
   
  
    async runGraph(initialInput: any, thread: any) {
      await this.sendMessage({ event: 'run_graph', data: { initial_input: initialInput, thread: thread } });
    }
    // Return an observable to subscribe to incoming messages
    getMessages(): Observable<string> {
      return this.messages.asObservable();
    }
    public setOnMessageHandler(handler: (event: MessageEvent) => void): void {
      if (this.socket) {
        this.socket.onmessage = handler;
      }
    }
    closeConnection(): void {
     
      if (this.socket) {
        // this.socket.close();
        this.socket.close(1000, 'Closing connection');
        console.log('WebSocket connection closed');
      }
    }
    // getDocument(): Observable<any> {
    //   let url='http://10.120.100.39:3200/tcquality';
    //    return this.http.post<any>(url,{"testCaseId": "0pA8vv-Mod-1-US-1-TC-2"});
     
    // }
    getDocument(): Observable<any> {
      let local_url='http://10.120.101.136:9006/latest_document';
      let server_url='https://10.120.101.147/latest_document';
      let url = 'http://10.120.100.39:3200/tcquality'
      //return this.http.post<any>(url,{"testCaseId": "5338"});
      return this.http.get<any>(server_url);
    }
  }

  
 
  // public gettestercopilottext(): Observable<any> {
  //   return this.http.get<any[]>(this.url + '/gettestercopilotcontext');
  // }

