import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestscriptgeneratorComponent } from './testscriptgenerator.component';

describe('TestscriptgeneratorComponent', () => {
  let component: TestscriptgeneratorComponent;
  let fixture: ComponentFixture<TestscriptgeneratorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestscriptgeneratorComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestscriptgeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
