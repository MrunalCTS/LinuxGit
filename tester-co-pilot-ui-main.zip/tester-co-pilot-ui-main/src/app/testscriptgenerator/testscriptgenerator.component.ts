import { Component, ViewChild, ElementRef,AfterViewInit, AfterViewChecked, Inject, PLATFORM_ID, signal, OnInit, inject, OnDestroy } from '@angular/core';
import { AbstractControl, Form, FormArray, FormBuilder, FormsModule } from '@angular/forms';
import { CodeEditor } from '@acrodata/code-editor';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { MatGridListModule } from '@angular/material/grid-list';
import {LanguageSupport, LanguageDescription, StreamParser, StreamLanguage} from "@codemirror/language"
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { BotWebSocketService } from '../bot-websocket.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogContentExampleDialogComponent } from '../dialog-content-example-dialog/dialog-content-example-dialog.component';
import { HttpClient } from '@angular/common/http';
import { interval, of, Subject } from 'rxjs';
import { catchError, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { EditorModule } from 'primeng/editor';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import 'codemirror/mode/clike/clike'; // Java is part of this mode
import { TemplateRef } from '@angular/core';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';

@Component({
  selector: 'app-testscriptgenerator',
  standalone: true,
  imports: [
    CodeEditor,
    RouterModule,
    CommonModule,
    FormsModule,
    MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatTabsModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatButtonToggleModule,
    MatExpansionModule,
    ReactiveFormsModule,
    MatListModule,
    EditorModule,
    DialogContentExampleDialogComponent,
    MatStepperModule
    
  ],
  templateUrl: './testscriptgenerator.component.html',
  styleUrl: './testscriptgenerator.component.css'
})
export class TestscriptgeneratorComponent implements OnInit, OnDestroy {
 
  languages=[LanguageDescription.of({
    name: "Java",
    extensions: ["java"],
    load() {
      return import("@codemirror/lang-java").then(m => m.java())
    }
  }),]
  query: any;
  chatForm!: FormGroup;
  mainForm!: FormGroup;
  selectedradioOption: any;
  submittedArr: any = [];
  @ViewChild('chatContainer', { static: false })
  private chatContainer!: ElementRef;
  @ViewChild('webchat', { static: false }) webchatElement!: ElementRef;
   isBrowser: boolean;
  readonly panelOpenState = signal(false);
  title = 'Bot WebSocket Client';
  selectedCheckboxes: boolean[] = [];
  selectedRadio: boolean[] = [];
  userMessage: string = '';
  testCasesCheckboxes: any = [];
  testCasesRadio: any = [];
  // botMessages: string[] = [];
  botMessages: any = [];
  userID:any='';
  //  socket: WebSocket=new WebSocket(environment.websocketUrl);
  question: string = '';
  agentId: string = 'agent_1';
  result: any;
  messageType: any;
  response: any;
  userInput = new FormControl('');
  checkboxOrRadioButtonClicked:boolean = false;
  testcaselistcount: any;
  testcopilottextdata: any;
  directoryData: any;
  codeMirrorContent: any;
  tableDataArray: { id: number; data: any[]; index?: number }[] = []; // Add 'index' as an optional property  tableData: any[] = [];
  testScriptData: any[] = [];
  tableDataList: any[] = []; // List to hold data for all tables
  currentTableIndex: number | null = null; // Index of the currently displayed table
  tableData: any[] = []; // Data for the currently displayed table
  accordionArray: any[] = [];
  currentWidget: string = '';
  codeMirrorOptions = {
    lineNumbers: true,
    theme: 'default',
    readOnly: true,
    viewportMargin: Infinity, // ensures all lines are rendered
    lineWrapping: true,       // enables word wrap
    scrollPastEnd: true       // allows scrolling past last line (optional)
  };
  combinedCode: any
  copySuccess = false;
   public url = 'http://10.120.101.34:3136/gettestercopilotcontext';
  private stop$ = new Subject<void>();
  // myForm = new FormGroup({
  //   myControl: new FormControl('Userstory description: As an employee, I want to apply for sabbatical leaves in my leave management system')
  // });

  buttonToggles = {
    info: 'info',
    links: 'links',
    docs: 'docs',
    media: 'media',
  };
  isChatBotLoading = false;

  buttonActive = this.buttonToggles.info;
  checkboxClicked: boolean=false;
  socket: WebSocket;
  steps = ['Context Gathering Agent', 'Web Crawling Agent', 'Test Step Detailing Agent', 'Test Script Generator Agent', 
    'Test Script Compiler Agent', 'Test Script Execution Agent', 'Failure Analyzer Agent', 'Script Healing Agent'
  ];
  //activeIndex = 1; // Currently active step (0-based) */
  //steps = ['First', 'Second', 'Third', 'Fourth'];
  activeIndex = 0; 
  isWorkFlowStarted = false;
  @ViewChild('stepper') stepper!: MatStepper;
 

  constructor(
    private botService: BotWebSocketService,
    private sanitizer: DomSanitizer,private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object,
    private fb: FormBuilder,
    public dialog: MatDialog, private http: HttpClient
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    // const WEBSOCKET_URL = 'ws://localhost:8080'; 
    this.socket = new WebSocket(environment.websocketUrl);
    // this.socket = new WebSocket(WEBSOCKET_URL);
    this.connectToWebSocket();
    // this.botService.registerAgent('run_graph');
   // Add a subscribe to complete the observable chain
    // this.gettestercopilottext();
  }
  openDialog(option: any): void {
    console.log('option', option);
    const dialogRef = this.dialog.open(DialogContentExampleDialogComponent, {
      height: "calc(90% - 30px)",
      width: "calc(85% - 30px)",
      maxWidth: "95%",
      maxHeight: "95%",
      data: { option }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      // console.log(`Dialog result: ${result}`);
    });
  }

 

  ngOnInit(): void {

    //this.botService.registerAgent('teststepscanner');
    
    this.mainForm = this.fb.group({
      ChatArray: this.fb.array([]),
    });
    this.botService.setOnMessageHandler((event) => {
      this.isChatBotLoading = false;
    console.log("",event);
      const data = JSON.parse(event.data);
      // console.log("data",data)
      if (data !== undefined && data !== null) {
        this.chatContentForm(data);
      }
    });

    
    /* setTimeout(() => {
      this.activeIndex = 1;
    }, 3000);

    setTimeout(() => {
      this.activeIndex = 2;
    }, 6000); */
    
    
  }

  getStatus(i: number): 'completed' | 'active' | 'pending' {
    if(i > this.activeIndex) return 'pending';
    if (i < this.activeIndex) return 'completed';
    if (i === this.activeIndex) return 'active';
    return 'pending';
  }

  updateStep(index: number) {
    this.activeIndex = index;
    if (this.stepper) {
      this.stepper.selectedIndex = index;
    }
  }
  
  ngOnDestroy(): void {
    // console.log('Destroying component');
    this.botService.closeConnection();
    this.socket.close();
    this.stop$.next();
    this.stop$.complete();
  }
  

  private connectToWebSocket(): void {
    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log('data', data);
      // this.botMessages.push(`Bot: ${data.text}`);
      if (data.text.includes('result')) {
        // console.log('result');
        const datatext = data.text;
        const datajson = JSON.parse(datatext);
        // console.log('datatexttype', datatext);
        if (datajson.type === 'TEXT') {
          this.botMessages.push({
            type: 'TEXT',
            value: `Bot: ${datajson.result}`,
          });
        }
        if (datajson.type === 'LIST - Checkbox') {
          if (/\n\d+/.test(datajson.result)) {
            // If the string contains newline followed by a number, split it into test cases
            this.testCasesCheckboxes = datajson.result
              .split(/\n\d+\./)
              .slice(1);
          } else {
            // If the string does not contain newline followed by a number, push the whole string into testCases
            this.testCasesCheckboxes = [datajson.result];
          }
          //this.updateTestCasesCheckboxes('checkbox', this.testCasesCheckboxes);
          // this.testCases = datajson.result.split(/\n\d+\./).slice(1); // Use slice(1) to remove the first element which is the "Here is the list of test cases:" string
          // console.log('testCasesCheckbox', this.testCasesCheckboxes);
          this.selectedCheckboxes = Array(this.testCasesCheckboxes.length).fill(
            false
          ); // Initialize all checkboxes to false
          this.botMessages.push({
            type: 'CHECKBOX',
            value: `Bot: ${datajson.result}`,
            testCasesCheckboxes: this.testCasesCheckboxes,
          });
        }
        if (datajson.type === 'LIST - Radio') {
          if (/\n\d+/.test(datajson.result)) {
            // If the string contains newline followed by a number, split it into test cases
            this.testCasesRadio = datajson.result.split(/\n\d+\./).slice(1);
          } else {
            // If the string does not contain newline followed by a number, push the whole string into testCases
            this.testCasesRadio = [datajson.result];
          }
          //this.updateTestCasesCheckboxes('radiobutton', this.testCasesRadio);
          // this.testCases = datajson.result.split(/\n\d+\./).slice(1); // Use slice(1) to remove the first element which is the "Here is the list of test cases:" string
          // console.log('testCasesRadioButton', this.testCasesRadio);
          this.selectedRadio = Array(this.testCasesRadio.length).fill(false);
          this.botMessages.push({
            type: 'RADIO',
            value: `Bot: ${datajson.result}`,
            testCasesRadio: this.testCasesRadio,
          });
        }
      } else {
        
        this.botMessages.push({ type: 'BOT', value: `Bot: ${data.text}` }); // Append bot's response to messages array
        console.log('botMessages', this.botMessages);
      }
      console.log('Received message:', data, data.text);
    };

    // Log when WebSocket is successfully connected
    this.socket.onopen = () => {
      console.log('WebSocket connection opened.');
    };

    // Handle WebSocket errors
    this.socket.onerror = (error) => {
      console.error('WebSocket error occurred: ', error);
    };

    // Automatically reconnect if WebSocket is closed
    this.socket.onclose = () => {
      console.log('WebSocket connection closed. Reconnecting...');
      setTimeout(() => this.connectToWebSocket(), 1000); // Reconnect after 1 second
    };
  }
  public setSocket(value: any): void {
    this.socket = value;
  }
  replaceNewlines(testCase: string): SafeHtml {
    const text = testCase.replace(/\n/g, '<br />');
    return this.sanitizer.bypassSecurityTrustHtml(text);
  }
  updateTestCasesCheckboxes(type: string, newTestCases: string[]) {
    if (type === 'checkbox') {
      this.testCasesCheckboxes = [...this.testCasesCheckboxes, ...newTestCases]; // Add new test cases to the existing ones
      
    } else {
      this.testCasesRadio = [...this.testCasesRadio, ...newTestCases]; // Add new test cases to the existing ones
     
    }
  }
 
  onSubmit(value: any) {
  
    const selectedTestCasesCheckboxes = this.testCasesCheckboxes.filter(
      (testCase: any, i: any) => this.selectedCheckboxes[i]
    );
   
    const selectedTestCasesRadio = this.testCasesRadio.filter(
      (testCase: any, i: any) => this.selectedRadio[i]
    );
    
    if (value.type === 'CHECKBOX') {
      console.log(selectedTestCasesCheckboxes); // Replace this with your actual submission logic
      this.userMessage = selectedTestCasesCheckboxes.join('\n');
      this.sendMessage();
    } else {
      this.userMessage = selectedTestCasesRadio.join('\n');
      this.sendMessage();
      // Replace this with your actual submission logic
    }
  }

  onCancel(value: any) {
    if (value === 'CHECKBOX') {
      this.selectedCheckboxes = [];
    } else {
      this.selectedRadio = []; // Clear the selection
    }
  }
  ngAfterViewChecked() {
    
   if(this.checkboxClicked){
    this.checkboxOrRadioButtonClicked = true;
    this.checkboxClicked=false;
   }
    else if (this.chatContainer && !this.checkboxOrRadioButtonClicked) {
     this.scrollToBottom()
     
    } 
    else if (this.checkboxOrRadioButtonClicked) {
      this.checkboxOrRadioButtonClicked = false;
      
    }
     else {
      console.error('chatContainer is not defined');

    }
    
  }
 
  // Method to send user message to the bot
  sendMessage(): void {
    console.log('Sending message:', this.userMessage);
    if (this.userMessage.trim()) {
      // Append user's message to the chat box
      this.botMessages.push({ type: 'YOU', value: `You: ${this.userMessage}` });
      // this.botMessages.push(`You: ${this.userMessage}`);

      // Send message to the bot via WebSocket
      const payload = {
        type: 'message',
        text: this.userMessage,
      };

      if (this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify(payload));
      } else {
        console.error('WebSocket is not open. Cannot send message.');
      }

      // Clear the input field
      this.userMessage = '';
    }
  }
  openPopupSubmit(chat:any): void {
    
this.isChatBotLoading = true;

const userChoice = this.userInput.value; 
// const userChoice = this.userMessage;
this.isWorkFlowStarted = true;
this.botService.sendMessage({
   event: 'teststepscanner',
   agent_id: this.agentId,
   testCase: userChoice
});



   
  }
  scrollToBottom(): void {
    try {
      // console.log('Scrolling to bottom');
      // console.log('scrollHeight:', this.chatContainer.nativeElement.scrollHeight);
      // console.log('clientHeight:', this.chatContainer.nativeElement.clientHeight);
      this.chatContainer.nativeElement.scrollTop =
        this.chatContainer.nativeElement.scrollHeight;
    } catch (err) {
      console.error('Scroll to bottom failed:', err);
    }
  }
  onClickClose(){
    window.location.reload();
  }
  sendResponse() {
    const userChoice = this.userMessage;
    this.botService.sendMessage({
      event: 'user_response',
      agent_id: this.agentId,
      user_choice: userChoice,
    });
  }

  parseAndSetResponse(response: string): void {
    // debugger
    try {
      const cleanedResponse = response

        .replace(/\n/g, '\\n') // Escape newline characters

        .replace(/\t/g, '\\t') // Escape tabs

        .replace(/\\/g, '\\\\'); // Escape backslashes
      const parsedResponse = JSON.parse(cleanedResponse);

      this.response = parsedResponse.result || '';

      this.messageType = parsedResponse.type || '';
      console.log('parsed...', this.response, 'msg type....', this.messageType);
      this.response = this.response
        .replace(/\\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    } catch (error) {
      console.error('Error parsing response:', error);
    }
  }

  chatContentForm(data: any, userChat: boolean = false) {
    let cForm = this.fb.group({
      chatContent: this.fb.array([]),
      type: new FormControl(null),
      chatHeading: new FormControl(null),
      selectedOption: new FormControl(null),
      widget: new FormControl(null),
      style: new FormControl(''),
      chatQuestion: new FormControl(null), // add this line
      userChat: new FormControl(userChat),
      isDisplay: new FormControl(false),
      // bulletPointType:new  FormControl(''),
      loadingmsg: new FormControl(''),
      tableData: new FormControl([]), 
      scanData: new FormControl<any[]>([]), // <-- Explicitly type as any[]


    });

    cForm.controls['chatHeading'].setValue(data.text);
    cForm.controls['widget'].setValue(data.widget);
    cForm.controls['type'].setValue(data.type);
    cForm.controls['style'].setValue(data.style);
    cForm.controls['loadingmsg'].setValue(data.loadingmsg);
    const chatContentArray = cForm.get('chatContent') as FormArray;
    console.log("chatContentArray",chatContentArray)

    chatContentArray.clear();

    if (userChat) {
      cForm.controls['selectedOption'].setValue(data.selectedOption);
    }

    if (data.widget == 'codemirrorWidget') {
      this.combinedCode = JSON.parse(data.value)
      this.codeMirrorContent = this.combinedCode.join('\n');
      cForm.controls['chatHeading'].setValue(this.combinedCode)
    }

    if (data.widget === 'displaytable') {
      console.log('data', data);
    
      const tableArray = data.value;
      if (Array.isArray(tableArray) && tableArray.length > 0) {
        data.value.tableData = tableArray; 
      } else {
        console.error('Invalid data.value format. Expected an array of objects.');
        data.value.tableData = [];
      }

      cForm.controls['tableData'].setValue(data.value.tableData); 
      console.log('tableData', this.tableData);
    }


    // Handle accordion data
    if (data.widget === 'displayExtractedSteps') {
      this.currentWidget = data.widget;

        let parsedData: any[] = [];
      try {
        parsedData = typeof data.value === 'string' ? JSON.parse(data.value) : data.value;
      } catch (e) {
        console.error('Invalid JSON string in data.value:', data.value);
        return;
      }
      console.log('parsedData', parsedData);
      this.accordionArray = []; 
      if (Array.isArray(parsedData)) {
        this.accordionArray = parsedData.map((obj: any) => {
          const userStep = Object.keys(obj)[0];
          const generatedSteps = obj[userStep];
          return { userStep, generatedSteps,  expanded: Array.isArray(generatedSteps) && generatedSteps.length > 0 };
        });
      } else {
        this.accordionArray = [];
      }
      cForm.controls['scanData'].setValue(this.accordionArray);
    }



    if(data.widget == 'testscriptWidget'){
      console.log('data.value', data);
      this.testScriptData = data.value
    }

    if(data.widget == 'workflowstatusWidget'){
      //this.activeIndex = data.value;
      this.updateStep(data.value);
    }



    if (data.widget == 'welcomewidget') {
      data.value.forEach((val: any) => {
        const group = new FormGroup({
          // isSelected:new FormControl(false),
          text: new FormControl(val),
        });

        chatContentArray.push(group);
      });
    }
    if (data.widget == 'tracewidget') {
      cForm.controls['chatHeading'].setValue(data.value)
    }
    if (data.type == 'nested-dict' && data.widget == 'editandsubmit') {

      let dt = data.value
        .replace(/\n/g, '')

        .replace(/\t/g, '')

        .replace(/\\/g, '');
      let dat = JSON.parse(data.value);
      

      Object.keys(dat).forEach((itr) => {
        if(itr==='list_of_new_test_scenarios_to_be_created')
        {

          Object.keys(dat[itr]).forEach((dt) => {
            
            let keyControl = new FormControl(dt);
            let group = new FormGroup({
              key: keyControl,
              parentKey:new FormControl(itr),
              val: this.editAndSubmitArray(dat[itr][dt]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
            });
            chatContentArray.push(group);
          })

        }
        else{
          let keyControl = new FormControl(itr);
          let group = new FormGroup({
            key: keyControl,
            val: this.editAndSubmitArray(dat[itr]), // Fix: Change the type to FormControl instead of AbstractControl<any, any>[]
          });
          chatContentArray.push(group);
        }
        
      });
    }

    if (data.type == 'dict') {
      Object.entries(JSON.parse(data.value)).forEach((itr) => {
        if (data.style == 'bulletpoint') {
          let type = typeof itr[1];
          // cForm.controls['bulletPointType'].setValue(typeof(itr[1]));

          if (type == 'string' || type != 'object') {
            let group = new FormGroup({
              key: new FormControl([itr[0]]),
              val: new FormControl([itr[1]]),
              bulletPointType: new FormControl(type),
            });
            chatContentArray.push(group);
          }
          if (type == 'object') {
            let group = new FormGroup({
              key: new FormControl([itr[0]]),
              selectedBulletPoints: new FormControl(''),
              val: this.bulletPointsArr([itr[1]]),
              bulletPointType: new FormControl(type),
            });
            chatContentArray.push(group);
          }
        }
        else {
          let group = new FormGroup({
            key: new FormControl([itr[0]]),
            val: new FormControl([itr[1]]),
          });
          chatContentArray.push(group);
        }
        if (data.style == 'testcaseaccordion') {
         
          const itrAny: any = itr; // Fix: Explicitly type itr as any
          this.testcaselistcount = itrAny[1].length; // Fix: Use itrAny instead of itr
          // console.log('testcaselistcount', this.testcaselistcount);
        }
      });
    }
    if (data.type == 'display' || data.widget == 'contextDisplay') {
      Object.entries(data.value).forEach((itr) => {
        let group = new FormGroup({
          key: new FormControl([itr[0]]),
          val: new FormControl([itr[1]]),
        });
        chatContentArray.push(group);
      });
    }

    if (data.widget == 'yesnowidget') {
      cForm.addControl('chatQuestion', new FormControl(data.text));
      const group = new FormGroup({
        isEditableMode: new FormControl(false),
        text: new FormControl('Yes'),
        // selectedOptionRbtn:new FormControl('')
      });

      chatContentArray.push(group);
      const qgroup = new FormGroup({
        isEditableMode: new FormControl(false),
        text: new FormControl('No'),
        // selectedOption:new FormControl('')
      });

      chatContentArray.push(qgroup);
    }

    if (data.type == 'checkbox') {
     
      data.value.forEach((content: any) => {
        const group = new FormGroup({
          checked: new FormControl(false),
          isEditableMode: new FormControl(false),
          text: new FormControl(content),
        });

        chatContentArray.push(group);
      });
    }
    if (data.type == 'radiobtn') {
      data.chatContent.forEach((content: string) => {
        const group = new FormGroup({
          isEditableMode: new FormControl(false),
          text: new FormControl(content),
          // selectedOption:new FormControl('')
        });

        chatContentArray.push(group);
      });
    }

    
    let chats = this.mainForm.get('ChatArray') as FormArray;
    chats.push(cForm);
    //  let  chats=this.mainForm.get('ChatArray') as FormArray;
    //  chats.push(cForm)
    // console.log('this.mainForm', cForm);
  }
  onClickAdd(chatForm: any, arrName: any) {
  
    let formArray = chatForm.get(arrName) as FormArray;
  
    if (formArray) {
      const group = new FormGroup({
        checked: new FormControl(false),
        isEditableMode: new FormControl(false),
        text: new FormControl('Enter text here'),
      });
      formArray.push(group);
    } else {
      console.error(`No control found with the name ${arrName}`);
    }
    // console.log(chatForm);
    this.checkboxOrRadioButtonClicked=true;
  }
  onChangeText(option: any, sec: any) {
 

    option.controls['isEditableMode'].setValue(false)
   
  }
  get contentFormArray() {
    return this.chatForm.controls['chatContent'] as FormArray;
  }
  get chatsArray() {
    return this.mainForm.controls['ChatArray'] as FormArray;
  }
  onSelectYesNO(option: any, chatForm: any, event: any) {
    this.isChatBotLoading = true;
    chatForm.controls['isDisplay'].setValue(true);
    chatForm.controls['selectedOption'].setValue(event.target.value);
    this.botService.sendMessage({ user_choice: event.target.value });
  }
  // @ts-ignore
  onEditSubmit(chat, event, chatForm) {
    chatForm.controls['isDisplay'].setValue(true);
    chatForm.controls['selectedOption'].setValue(event.target.value);
    let scenerioData = {};
    
    let arr: any = [];
    let prev:any=''
    chat.value.chatContent.forEach((ct: any) => {
     
      if(prev!=='list_of_new_test_scenarios_to_be_created')
      {
         arr= [];
      }
   prev=ct.parentKey;
      if (Array.isArray(ct.val)) {
        ct.val.forEach((val: any) => {
          if (val.checked) {
            this.submittedArr = arr.push(val.text);
          }
        });
        
        if(ct.parentKey==='list_of_new_test_scenarios_to_be_created')
        {
          scenerioData = { ...scenerioData, [ct.parentKey]: arr };
        }
        else{
          scenerioData = { ...scenerioData, [ct.key]: arr };
        }
        
      }
    });
    this.botService.sendMessage({
      val: scenerioData,
      action: event.target.value,
    });
   this.checkboxOrRadioButtonClicked=false;

  }

  onEditSelect(chat: any, arrName: string) {
    // debugger
    chat.controls['isDisplay'].setValue(true);

    let formArray = chat.get(arrName) as FormArray;
    let arr: any = [];
    formArray.value.forEach((val: any) => {
      if (val.checked) {
        this.submittedArr = arr.push(val.text);
      }
    });
    this.botService.sendMessage({ checked: arr });
  // this.onCheckboxOrRadioButtonClick()
  }

  getChatContentControls(chat: AbstractControl): AbstractControl[] {
    const chatContent = (chat as FormGroup).get('chatContent') as FormArray;
    // console.log("chatContent",chatContent)
    return chatContent ? chatContent.controls : [];
  }
  getOptionValContentControls(option: AbstractControl): AbstractControl[] {
    const optioncontent = (option as FormGroup).get('val') as FormArray;
    
    return optioncontent ? optioncontent.controls : [];
  }

  onChangeEditText(chat: any) {
    let arr: any = [];
    chat.value.forEach((val: any) => {
      if (val.checked) {
        arr.push(val.text);
      }
    });
    this.botService.sendMessage({ checked: arr });
    
  }
  // @ts-ignore
  editAndSubmitArray(val: any): FormArray {
    let arr: FormGroup[] = [];
    val.forEach((itr: any) => {
      const group = new FormGroup({
        checked: new FormControl(false),
        isEditableMode: new FormControl(false),
        text: new FormControl(itr),
      });
      arr.push(group);
    });
    return new FormArray(arr);
  }

  onClickSubmit(val: any, chat: any) {
    chat.controls['selectedOption'].setValue(val);
  }

  bulletPointsArr(val: any): FormArray {
    let arr: FormGroup[] = [];
    val.forEach((itre: any) => {
      itre.forEach((itr: any) => {
        const group = new FormGroup({
          text: new FormControl(itr),
        });
        arr.push(group);
      });
    });
    return new FormArray(arr);
  }

  enableEditMode(option: any) {
    option.controls['isEditableMode'].setValue(true);
    this.checkboxOrRadioButtonClicked=true;
  }

  removeUnderScore(str: string[]) {
    let newstr = str[0].split('_').join(' ');
    
    return newstr;
  }

  formatString(chat: any, str: string) {
    switch (chat.value.style) {
      case 'bulletpoint':
        if (Array.isArray(str)) {
          str = str.reduce((acc, val) => acc + val, '');
        }
        str = str.replaceAll('\n', '<br><br>');
        break;
    }
    return str;
  }

  logger(...param: any[]) {
   
  }

  toggleButton(button: string) {
    this.buttonActive = button;
  }
  toggleExpanded(item: any) {
    item.expanded = !item.expanded;
  }
  onClickEdit() {
  
  }
  onProceed() {
  }
  handleSaveData(data: any) {
   
  }
  onCheckboxOrRadioButtonClick() {

    this.checkboxOrRadioButtonClicked = true;
    
    // !this.chatContainer;
   
  }
  oncheckboxClicked(){
    this.checkboxClicked=true;
  }
  isArray(obj: any): boolean {
    return Array.isArray(obj)
  }
  navigateHome(): void {
    this.router.navigate(['']);
  }

  copyCode() {
    if (navigator.clipboard && this.codeMirrorContent) {
      navigator.clipboard.writeText(this.codeMirrorContent).then(() => {
        this.copySuccess = true;
        setTimeout(() => {
          this.copySuccess = false;
        }, 1500);
      }).catch(err => {
        console.error("Copy failed: ", err);
      });
    }
  }
  copyScriptCode(fileData: string) {
    if (navigator.clipboard && fileData) {
        navigator.clipboard.writeText(fileData).then(() => {
            this.copySuccess = true;
            setTimeout(() => {
                this.copySuccess = false;
            }, 1500);
        }).catch(err => {
            console.error("Copy failed: ", err);
        });
    }
}

openScreenshot(base64Image: string, dialogTemplate: TemplateRef<any>): void {
    const imagePath = 'data:image/png;base64,' + base64Image;
    this.dialog.open(dialogTemplate, {
      data: imagePath,
      panelClass: 'screenshot-dialog'
    });
  }

}



