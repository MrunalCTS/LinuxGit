import { Component, ChangeDetectorRef, NgZone } from '@angular/core';
import { BotWebSocketService } from '../bot-websocket.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
  userMessage: string = '';
  botMessages: string[] = [];
  question: string = '';
  agentId: string = 'agent_1';
  result: any;
  messageType: any;
  response: any;

  constructor(private botService: BotWebSocketService, private cdr: ChangeDetectorRef, private ngZone: NgZone) {
    // Subscribe to incoming bot messages
    this.botService.getMessages().subscribe((message) => {
      this.botMessages.push(`bot: ${message}`);
    });
  }

  ngOnInit(): void {
    // Register an agent when the component initializes
    this.botService.registerAgent('agent_1');

    // Listen for messages from the server
    this.botService.socket.onmessage = (event) => {
      // console.log(event)
      //  this.ngZone.run(()=>{
      const data = JSON.parse(event.data);
      // debugger


      //this.chatContentForm(data)
      //  let  cArray= this.chatForm.controls['chatArray'] as FormArray
      //  if(data){
      //   this.chatForm.controls['chatArray'].setValue(this.chatContentForm(data))
      //  }

      // this.cdr.detectChanges()
      //   })
      //console.log("Chat FORM", this.chatForm)
    };
  }

  submit() {
    const userChoice = this.userMessage;
    this.botService.sendMessage({ event: 'run_graph', agent_id: this.agentId, user_choice: userChoice });
  }


  sendResponse() {
    const userChoice = this.userMessage;
    this.botService.sendMessage({ event: 'user_response', agent_id: this.agentId, user_choice: userChoice });
  }

  // Send user message to bot
  sendMessage(): void {
    if (this.userMessage.trim()) {
      this.botMessages.push(`user: ${this.userMessage}`);
      this.botService.sendMessage(this.userMessage);  // Send message to the bot
      this.userMessage = '';  // Clear input
    }
  }
}
