import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatRippleModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { BotWebSocketService } from '../bot-websocket.service';
// import { BotWebSocketService } from '../bot-websocket.service';
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule, MatButtonModule, MatIconModule, CommonModule, MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatTabsModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRippleModule,
    MatButtonToggleModule,
    MatExpansionModule,
    MatListModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',

})
export class HomeComponent {
  constructor(private route: Router,private botService: BotWebSocketService) {

  }
  //    list={

  //     TestCasecreation:{
  //     'name':'Test Case Creation',
  //     'description':'Generate relevant test cases by identifying the requirement lapses & coverage gaps.'},
  //     TestDataProvisioning:{
  //        'name':'Test Data Provisioning',
  //     'description':'Provision your desired test data for the given set of features or functionality being tested.'
  //     },
  //     RiskbasedTesting:{
  //       'name':'Risk based Testing',
  //       'description':'Select the right set of Test suite to execute based on the stage of testing, and time constraints'},
  //       TestScriptGeneration:{
  //         'name':'Test Script Generation',
  //         'description':'Generate test scripts for your feature, in alignment with your current framework standards'},


  //   TestScriptMaintenance:{
  //     'name':'Test Script Maintenance',
  //         'description':'Reduce the maintenance effort by recommending script changes in sync with app updates',
  //   },

  // DefectTriaging:{
  //     'name':'Defect Triaging',
  //         'description':'Prioritize and resolve defects faster with insights on root cause analysis & prior history',
  //   },
  // GenerateJMeterScripts:{
  //   'name':'Generate JMeter Scripts',
  //       'description':'Generate scripts for performance testing based on your current functional testcase',
  // },

  // }
  list = [
    { id: 'TestCasecreation', name: 'Test Case Creation', description: 'Generate relevant test cases by identifying the requirement lapses & coverage gaps.' },
    { id: 'Review Testcases', name: 'Review Testcases', description: 'Review Test cases for Completeness, Correctness, Consistency and Coverage' },
    { id: 'TestDataProvisioning', name: 'Test Data Provisioning', description: 'Provision your desired test data for the given set of features or functionality being tested.' },
    { id: 'RiskbasedTesting', name: 'Risk based Testing', description: 'Select the right set of Test suite to execute based on the stage of testing, and time constraints' },
    { id: 'TestScriptGeneration', name: 'Test Script Generation', description: 'Generate test scripts for your feature, in alignment with your current framework standards' },
    { id: 'TestScriptMaintenance', name: 'Test Script Maintenance', description: 'Reduce the maintenance effort by recommending script changes in sync with app updates' },
    { id: 'DefectTriaging', name: 'Defect Triaging', description: 'Prioritize and resolve defects faster with insights on root cause analysis & prior history' },
    { id: 'GenerateJMeterScripts', name: 'Generate JMeter Scripts', description: 'Generate scripts for performance testing based on your current functional testcase' }
  ];
  onClickWidget(item: any) {

    if (item.id === 'TestCasecreation') {
        this.route.navigate(['testcasecreation']);
        
    }
    else if (item.id === 'TestDataProvisioning') {

      this.route.navigate(['testdataprovisioning']);

    }
    else if (item.id === 'Review Testcases') {

      this.route.navigate(['qualitycompanion']);

    } else if(item.id === 'TestScriptGeneration'){
      this.route.navigate(['testscriptgeneration']);
    }
    
}
  onClickAskYourBuddy() {
    // console.log('ask your buddy');
    this.route.navigate(['/askyourbuddy']);
  }
  onClickQualityCompanion(){
    this.botService.registerAgent('testdatageneration');
    this.route.navigate(['qualitycompanion'])
  }
}
