import { Component, OnInit, ViewChild, Inject, Output, EventEmitter, importProvidersFrom, TemplateRef, ViewEncapsulation } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MatDialogModule, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { BotWebSocketService } from '../bot-websocket.service';
import { HttpClient } from '@angular/common/http';
import {MatSnackBar, MatSnackBarModule} from '@angular/material/snack-bar'; 


@Component({
  selector: 'app-dialog-content-example-dialog',
  standalone: true, // Mark this component as standalone
  templateUrl: './dialog-content-example-dialog.component.html',
  styleUrl: './dialog-content-example-dialog.component.css',
  encapsulation: ViewEncapsulation.None,
  imports: [MatDialogModule, CommonModule, FormsModule, MatFormFieldModule, MatCheckboxModule,
     MatPaginatorModule, MatTableModule, MatIconModule,MatSnackBarModule]
})

export class DialogContentExampleDialogComponent  {
  testcases_url='https://10.120.101.147/create_test_case';
  displayedColumns: string[] = ['TCStepName', 'ExpectedResult', 'Action'];
  testCasesArr: any = [];
  pushtestCasesArr:any = {
    testCaseID: "vmOiEQ-Mod-1-US-1-TC-1",
    testCaseName: '',
    description: '',
    testStep: [],
    expectedResult: []
  }
  testCasesNameVal: any;
  dataSource = new MatTableDataSource<ModelData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @Output() saveData = new EventEmitter<any>();
  @ViewChild('successDialog') successDialog!: TemplateRef<any>;
  constructor(
    public dialogRef: MatDialogRef<DialogContentExampleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private route: Router,private http: HttpClient,
    private botService: BotWebSocketService,private dialog: MatDialog,private _snackBar: MatSnackBar) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    console.log(this.data);
    this.data = this.data.option;
    this.testCasesNameVal = this.data.testCaseName;
    //console.log(this.data, this.testCasesNameVal);
    //this.testCasesArr.push({ teststepsName: this.data.testSteps, description: this.data.description, expectedresult: this.data.expectedResult });
    // if (this.data) {
    //   //this.testCasesArr.push({ description: this.data.description });
    //   this.data.testSteps.forEach((val: any, index: any) => {
    //     this.data.expectedResult.forEach((er: any) => {
    //     this.testCasesArr.push({ select: "", teststepsName: val,expectedresult: er});
    //   });

    //   });
    //   console.log("",this.testCasesArr)
    //   // this.data.expectedResult.forEach((val: any) => {
    //   //   this.testCasesArr.push({ expectedresult: val });
    //   //   console.log("",this.testCasesArr)
    //   // });
    // }
    if (this.data) {
      // && i < this.data.expectedResult.length
      for (let i = 0; i < this.data.testSteps.length; i++) {
        this.testCasesArr.push({
          select: "",
          teststepsName: this.data.testSteps[i].stepDetails,
          expectedresult: this.data.testSteps[i].expectedResult,
          isEditing: false
        });
      }
      for (let i = 0; i < this.data.testSteps.length; i++) {
        this.pushtestCasesArr.testStep.push(this.data.testSteps[i].stepDetails);
        this.pushtestCasesArr.expectedResult.push(this.data.testSteps[i].expectedResult);
      }
      this.pushtestCasesArr.testCaseName =  this.data.testCaseName,
      this.pushtestCasesArr.description = this.data.description;
    }
    console.log("pushtestCasesArr", this.testCasesArr,this.pushtestCasesArr);
    this.dataSource = new MatTableDataSource<ModelData>(this.testCasesArr);
    this.dataSource.paginator = this.paginator;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  edit(element: any) {
    element.isEditing = true;
  }

  delete(element: any): void {
    // code to delete the element
  }
  save(element: any, index: any) {
    // console.log('element', element);
    // Find the index of the element in the testSteps array
    // const index = this.data.testSteps.findIndex((step: any) =>
    //   step === element.teststepsName);

    // Update the element in the testSteps array
    if (index !== -1) {
      this.data.testSteps[index] = element.teststepsName;
    }

    // Set isEditing to false
    element.isEditing = false;
    // console.log('savedialogbox', this.data);
    this.dialogRef.close(this.data);
    this.saveData.emit(this.data);
  }
  pushTestCases(): void {
    this.http.post(this.testcases_url, this.pushtestCasesArr).subscribe(
      response => {
        // Handle the response here
        console.log('pushTestCasesResponse',response);
        if(response){
          response = (response as any).testCaseID;
          this.showSuccessMessage(response);
          console.log('Saved Successfully');
          this.dialogRef.close(this.data);
          this.saveData.emit(this.data);
          this.route.navigate([''])
        }
      },
      error => {
        // Handle the error here
        console.error(error);
      }
    );
  }

  showSuccessMessage(response: any): void {
    this._snackBar.open(response.toString() + ' testcase Id pushed successfully!', 'OK', { 
      duration: 2500,
      horizontalPosition: 'right',
      verticalPosition: 'bottom',
      panelClass: ['success-snackbar']
    });
  }

}
export interface ModelData {
  teststepsName: number;
  // description: string;
  expectedresult: string;
}
