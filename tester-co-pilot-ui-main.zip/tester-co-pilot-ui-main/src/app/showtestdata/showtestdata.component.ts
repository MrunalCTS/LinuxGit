import { Component, OnInit, ViewChild, Inject, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-showtestdata',
  standalone: true,
  imports: [MatDialogModule, CommonModule, FormsModule, MatFormFieldModule, MatCheckboxModule, MatPaginatorModule, MatTableModule, MatIconModule],
  templateUrl: './showtestdata.component.html',
  styleUrl: './showtestdata.component.css'
})
export class ShowtestdataComponent {
  displayedColumns: string[] = ['TCStepName', 'ExpectedResult'];
  testCasesArr: any = [];
  testCasesNameVal: any;
  dataSource = new MatTableDataSource<ModelData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @Output() saveData = new EventEmitter<any>();
  constructor(
    public dialogRef: MatDialogRef<ShowtestdataComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    console.log(this.data);
    this.data = this.data.option.value;
    this.testCasesNameVal = this.data.tcname;
    if (this.data) {
      // && i < this.data.expectedResult.length
      // debugger
      // for (let i = 0; i < this.data.stepname.length ; i++) {
      //   this.testCasesArr.push({
      //     teststepsName: this.data.stepname[i],
      //     expectedresult: this.data.expectedresult[i],
      //   });
      // }
      this.testCasesArr.push({
        teststepsName: this.data.testSteps,
        expectedresult: this.data.expectedResults,
      });
    }
    this.dataSource = new MatTableDataSource<ModelData>(this.testCasesArr);
    console.log(this.dataSource);
    this.dataSource.paginator = this.paginator;

  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
}
export interface ModelData {
  teststepsName: string;
  // description: string;
  expectedresult: string;
}
