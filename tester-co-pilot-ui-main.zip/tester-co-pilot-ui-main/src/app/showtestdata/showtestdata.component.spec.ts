import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowtestdataComponent } from './showtestdata.component';

describe('ShowtestdataComponent', () => {
  let component: ShowtestdataComponent;
  let fixture: ComponentFixture<ShowtestdataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowtestdataComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowtestdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
